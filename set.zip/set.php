<?php
declare(strict_types=1);
/**
 * AWFLWIKIWORLD — setup wizard (set.php)
 * Collects site configuration, validates it, then generates / updates config.php.
 */

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

$ROOT     = __DIR__;
$CONFIG   = $ROOT . '/config.php';
$LOGO_DIR = $ROOT . '/logo';

/* ============================================================
   Canonical template (used when config.php does not exist yet)
   ============================================================ */
$AWFL_TEMPLATE = <<<'AWFLTEMPLATE'
<?php
/**
 * AWFLWIKIWORLD — Site Configuration
 * Edit the values below to configure your wiki.
 */

// ---- Site identity ----
$Sitename        = "";
$MetaTitle       = "";
$MetaDescription = "";

// ---- Server / paths ----
// The base URL of your wiki, no trailing slash (e.g. "https://example.com/wiki"
// or "http://localhost:8080"). This is NOT auto-detected — auto-detection was
// removed because it breaks in real hosting setups (reverse proxies, CLI/cron
// contexts, subdirectory scripts like dashboard/ or sitemap/ computing a
// different "root" than index.php, etc). Set this explicitly and every URL
// and asset link in the system is built from it.
$Server = "http://";

// Logo path. Can be absolute URL, relative path, or full path.
$Logo = "logo/aedtpworld.svg";

// Active skin CSS. Can be absolute URL, relative, or full path.
$Skin = "skins/vector2022.css";

// ---- Admin account ----
// Exact admin username / password (plaintext here; the system hashes it on
// first use — see includes/functions.php::awfl_verify_admin()).
$Username = "";
$Password = "";

// ---- Uploads ----
$ImageUpload      = true;  // allow logged-in users to upload images
$ExternalImageUrl = true;  // allow external image URLs (e.g. in infoboxes)

// ---- URL routing style ----
// "0" => index.php?title=Pagename            (and ?title=Space/Pagename)
// "1" => /Pagename                           (and /Space/Pagename)   [pretty URLs, needs .htaccess]
// "2" => /namespaces/Pagename                (and /namespaces/Space/Pagename)
$route = "";

// ---- Session ----
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- Root path constant (filesystem, not URL) ----
define('AWFL_ROOT', __DIR__);

$Server = rtrim($Server, '/');
if ($Server === '') {
    http_response_code(500);
    die('AWFLWIKIWORLD is not configured yet: set $Server in config.php to your site\'s base URL (e.g. "http://localhost:8099" or "https://example.com/wiki").');
}

// ---- Admin dashboard runtime overrides (active skin + color palette) ----
// Stored separately from this file so the dashboard never has to rewrite
// PHP source — it just writes JSON here.
$AwflColors = [];
$__awfl_overrides_file = __DIR__ . '/dashboard/settings.json';
if (file_exists($__awfl_overrides_file)) {
    $__awfl_overrides = json_decode(file_get_contents($__awfl_overrides_file), true);
    if (is_array($__awfl_overrides)) {
        if (!empty($__awfl_overrides['skin'])) {
            $Skin = 'skins/' . basename($__awfl_overrides['skin']) . '.css';
        }
        if (!empty($__awfl_overrides['colors']) && is_array($__awfl_overrides['colors'])) {
            $AwflColors = $__awfl_overrides['colors'];
        }
    }
}
unset($__awfl_overrides_file, $__awfl_overrides);
AWFLTEMPLATE;

/* ============================================================
   Helpers
   ============================================================ */

function h(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function slen(string $s): int
{
    return function_exists('mb_strlen') ? (int)mb_strlen($s, 'UTF-8') : strlen($s);
}

/** Quote a value for a PHP double-quoted string literal. */
function php_quote(string $v): string
{
    return '"' . str_replace(['\\', '"', '$'], ['\\\\', '\\"', '\\$'], $v) . '"';
}

/** Reverse of php_quote(). */
function php_unquote(string $raw): string
{
    $raw = trim($raw);
    $len = strlen($raw);
    if ($len >= 2 && ($raw[0] === '"' || $raw[0] === "'") && $raw[$len - 1] === $raw[0]) {
        $inner = substr($raw, 1, -1);
        $out   = '';
        $n     = strlen($inner);
        for ($i = 0; $i < $n; $i++) {
            $ch = $inner[$i];
            if ($ch === '\\' && $i + 1 < $n) {
                $nx = $inner[$i + 1];
                if ($nx === '\\' || $nx === '"' || $nx === "'" || $nx === '$') {
                    $out .= $nx;
                    $i++;
                    continue;
                }
            }
            $out .= $ch;
        }
        return $out;
    }
    return $raw;
}

/** Read the current values out of an existing config.php (no side effects). */
function read_config_values(string $file): array
{
    if (!is_file($file)) {
        return [];
    }
    $src = @file_get_contents($file);
    if (!is_string($src) || trim($src) === '') {
        return [];
    }

    $keys = ['Server', 'Sitename', 'MetaTitle', 'MetaDescription', 'Logo',
             'Username', 'Password', 'ImageUpload', 'ExternalImageUrl', 'route'];
    $q    = '(?:"(?:\\\\.|[^"\\\\])*"|\'(?:\\\\.|[^\'\\\\])*\'|[^;]+)';
    $out  = [];

    foreach ($keys as $k) {
        if (preg_match('/\$' . preg_quote($k, '/') . '\s*=\s*(' . $q . ')\s*;/', $src, $m)) {
            $out[$k] = php_unquote($m[1]);
        }
    }
    return $out;
}

/** Best-effort base URL of this installation. */
function detect_server(): string
{
    if (PHP_SAPI === 'cli') {
        return '';
    }
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? '') == 443)
        || (strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https');

    $scheme = $https ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
    $dir    = str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/set.php')));
    $dir    = rtrim($dir, '/');
    if ($dir === '.' || $dir === '/') {
        $dir = '';
    }
    return $scheme . '://' . $host . $dir;
}

/**
 * Take a config.php source and swap in the new values.
 * Returns the new file contents; $missing lists keys that had to be appended.
 */
function build_config(string $src, array $values, string $server, array &$missing): ?string
{
    $missing = [];
    $q = '(?:"(?:\\\\.|[^"\\\\])*"|\'(?:\\\\.|[^\'\\\\])*\'|[^;]+)';

    $map = [
        'Server'           => php_quote($server),
        'Sitename'         => php_quote((string)$values['Sitename']),
        'MetaTitle'        => php_quote((string)$values['MetaTitle']),
        'MetaDescription'  => php_quote((string)$values['MetaDescription']),
        'Logo'             => php_quote((string)$values['Logo']),
        'Username'         => php_quote((string)$values['Username']),
        'Password'         => php_quote((string)$values['Password']),
        'ImageUpload'      => ($values['ImageUpload'] === 'true') ? 'true' : 'false',
        'ExternalImageUrl' => ($values['ExternalImageUrl'] === 'true') ? 'true' : 'false',
        'route'            => php_quote((string)$values['route']),
    ];

    foreach ($map as $key => $replacement) {
        $pattern = '/\$' . preg_quote($key, '/') . '\s*=\s*' . $q . '\s*;/';
        $count   = 0;
        $result  = preg_replace_callback(
            $pattern,
            static function () use ($key, $replacement): string {
                return '$' . $key . ' = ' . $replacement . ';';
            },
            $src,
            1,
            $count
        );
        if ($result === null) {
            return null; // regex blew up — do not write garbage
        }
        $src = $result;
        if ($count === 0) {
            $missing[] = $key;
        }
    }

    if ($missing) {
        $src = rtrim($src) . "\n\n// ---- Appended by set.php (not found in the previous config) ----\n";
        foreach ($missing as $k) {
            $src .= '$' . $k . ' = ' . $map[$k] . ";\n";
        }
    }

    return $src;
}

/** Pick the file we are editing: existing config.php, otherwise the template. */
function config_source(string $file, string $template): array
{
    if (is_file($file)) {
        $src = @file_get_contents($file);
        if (is_string($src) && trim($src) !== '' && strpos(ltrim($src), '<?php') === 0) {
            return [$src, true];
        }
    }
    return [$template, false];
}

/** Validate every scalar field. Returns the cleaned values. */
function validate_fields(array $post, array &$errors): array
{
    $v = [];

    $v['Sitename'] = trim((string)($post['Sitename'] ?? ''));
    if ($v['Sitename'] === '') {
        $errors['Sitename'] = 'Sitename is required.';
    } elseif (slen($v['Sitename']) > 50) {
        $errors['Sitename'] = 'Sitename must be 50 characters or fewer.';
    }

    $v['MetaTitle'] = trim((string)($post['MetaTitle'] ?? ''));
    if ($v['MetaTitle'] === '') {
        $errors['MetaTitle'] = 'MetaTitle is required.';
    } elseif (slen($v['MetaTitle']) > 50) {
        $errors['MetaTitle'] = 'MetaTitle must be 50 characters or fewer.';
    }

    $v['MetaDescription'] = trim((string)($post['MetaDescription'] ?? ''));
    if ($v['MetaDescription'] === '') {
        $errors['MetaDescription'] = 'MetaDescription is required.';
    } elseif (slen($v['MetaDescription']) > 160) {
        $errors['MetaDescription'] = 'MetaDescription must be 160 characters or fewer.';
    }

    $v['Username'] = trim((string)($post['Username'] ?? ''));
    if (slen($v['Username']) < 1) {
        $errors['Username'] = 'Username must be at least 1 character.';
    }

    $v['Password'] = (string)($post['Password'] ?? '');
    if (slen($v['Password']) < 8) {
        $errors['Password'] = 'Password must be at least 8 characters.';
    }

    foreach (['ImageUpload', 'ExternalImageUrl'] as $b) {
        $raw = (string)($post[$b] ?? '');
        if ($raw !== 'true' && $raw !== 'false') {
            $errors[$b] = 'Choose true or false.';
            $raw = 'true';
        }
        $v[$b] = $raw;
    }

    $r = (string)($post['route'] ?? '');
    if (!in_array($r, ['0', '1', '2'], true)) {
        $errors['route'] = 'Route must be 0, 1 or 2.';
        $r = '0';
    }
    $v['route'] = $r;

    return $v;
}

/** Handle the logo upload. Returns the "logo/..." path or an existing one. */
function handle_logo_upload(array $file, string $logoDir, string $existingLogo, array &$errors): ?string
{
    $allowed = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico', 'bmp', 'avif'];
    $hasUpload = isset($file['error']) && (int)$file['error'] !== UPLOAD_ERR_NO_FILE;

    if (!$hasUpload) {
        if ($existingLogo !== '') {
            return $existingLogo;
        }
        $errors['Logo'] = 'Please choose a logo image to upload.';
        return null;
    }

    if ((int)$file['error'] !== UPLOAD_ERR_OK) {
        $errors['Logo'] = 'Upload failed (error code ' . (int)$file['error'] . ').';
        return null;
    }
    if (!is_uploaded_file((string)$file['tmp_name'])) {
        $errors['Logo'] = 'Invalid upload.';
        return null;
    }
    if ((int)$file['size'] > 4 * 1024 * 1024) {
        $errors['Logo'] = 'The logo must be smaller than 4 MB.';
        return null;
    }

    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        $errors['Logo'] = 'Unsupported image type. Allowed: ' . implode(', ', $allowed) . '.';
        return null;
    }

    $mime = '';
    if (function_exists('finfo_open')) {
        $fi = @finfo_open(FILEINFO_MIME_TYPE);
        if ($fi) {
            $mime = (string)@finfo_file($fi, (string)$file['tmp_name']);
            @finfo_close($fi);
        }
    }
    if ($ext !== 'svg' && $mime !== '' && strpos($mime, 'image/') !== 0) {
        $errors['Logo'] = 'That file does not look like an image.';
        return null;
    }

    if (!is_dir($logoDir) && !@mkdir($logoDir, 0755, true) && !is_dir($logoDir)) {
        $errors['Logo'] = 'Could not create the "logo/" directory. Check permissions.';
        return null;
    }
    if (!is_writable($logoDir)) {
        $errors['Logo'] = 'The "logo/" directory is not writable.';
        return null;
    }

    $base = (string)pathinfo((string)$file['name'], PATHINFO_FILENAME);
    $base = (string)preg_replace('/[^A-Za-z0-9._-]+/', '-', $base);
    $base = trim($base, '-._');
    if ($base === '') {
        $base = 'logo-' . date('Ymd-His');
    }
    $base = substr($base, 0, 60);

    $filename = $base . '.' . $ext;
    $dest     = rtrim($logoDir, '/') . '/' . $filename;

    if (!@move_uploaded_file((string)$file['tmp_name'], $dest)) {
        $errors['Logo'] = 'Could not save the uploaded logo.';
        return null;
    }
    @chmod($dest, 0644);

    return 'logo/' . $filename;
}

/* ============================================================
   Rendering chrome
   ============================================================ */

function ui_head(int $step, string $title): void
{
    $labels = [1 => 'Configure', 2 => 'Review', 3 => 'Finish'];
    ?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($title) ?> · AWFLWIKIWORLD setup</title>
<style>
:root{
  --bg:#0b0e14; --panel:#12161f; --panel2:#171c27; --line:#242b39;
  --txt:#e6e9f0; --muted:#8b93a7; --accent:#6d5efc; --accent2:#22d3ee;
  --ok:#2dd4a7; --err:#ff6b81; --radius:14px;
}
*{box-sizing:border-box}
html,body{height:100%}
body{
  margin:0; background:var(--bg); color:var(--txt);
  font:15px/1.55 ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,Inter,sans-serif;
  -webkit-font-smoothing:antialiased;
}
.aurora{
  position:fixed; inset:0; pointer-events:none; z-index:0;
  background:
    radial-gradient(700px 380px at 12% -8%, rgba(109,94,252,.28), transparent 60%),
    radial-gradient(600px 340px at 92% 4%, rgba(34,211,238,.16), transparent 62%),
    radial-gradient(900px 500px at 50% 110%, rgba(109,94,252,.12), transparent 70%);
}
.wrap{position:relative; z-index:1; max-width:760px; margin:0 auto; padding:38px 20px 70px}
.masthead{display:flex; align-items:center; justify-content:space-between; margin-bottom:26px}
.brand{display:flex; align-items:center; gap:10px; font-weight:800; letter-spacing:.06em; font-size:14px}
.brand em{font-style:normal; color:var(--accent)}
.spark{
  width:11px; height:11px; border-radius:50%;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  box-shadow:0 0 14px rgba(109,94,252,.9);
}
.tag{
  font-size:11px; letter-spacing:.14em; text-transform:uppercase; font-weight:700;
  color:var(--muted); border:1px solid var(--line); padding:5px 10px; border-radius:999px;
  background:rgba(255,255,255,.02);
}
.steps{display:flex; gap:8px; list-style:none; padding:0; margin:0 0 20px}
.steps li{
  flex:1; text-align:center; padding:9px 8px; border-radius:10px;
  background:var(--panel2); border:1px solid var(--line); color:var(--muted);
  font-size:11px; font-weight:700; letter-spacing:.09em; text-transform:uppercase;
}
.steps li.active{
  color:#fff; border-color:transparent;
  background:linear-gradient(135deg,var(--accent),#8b5cf6);
  box-shadow:0 10px 24px -14px var(--accent);
}
.steps li.done{color:var(--ok); border-color:rgba(45,212,167,.35); background:rgba(45,212,167,.06)}
.card{
  background:linear-gradient(180deg, rgba(255,255,255,.025), rgba(255,255,255,0)) , var(--panel);
  border:1px solid var(--line); border-radius:var(--radius); padding:26px;
  box-shadow:0 30px 60px -40px #000;
}
h1{margin:0 0 6px; font-size:21px; letter-spacing:-.01em}
.lede{margin:0 0 22px; color:var(--muted); font-size:13.5px}
.lede code, code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace; font-size:.92em;
  background:rgba(255,255,255,.06); padding:1px 5px; border-radius:5px; color:#cfd6e6}
.field{margin-bottom:19px}
.field > label.lbl{display:block; font-size:13px; font-weight:650; margin-bottom:7px}
.req{color:var(--err); margin-left:2px}
input[type=text],input[type=password],textarea{
  width:100%; padding:11px 13px; border-radius:10px; border:1px solid var(--line);
  background:#0e121b; color:var(--txt); font:inherit; font-size:14px; outline:none;
  transition:border-color .15s, box-shadow .15s;
}
textarea{min-height:78px; resize:vertical}
input[type=text]::placeholder,textarea::placeholder{color:#4d5566}
input:focus,textarea:focus{border-color:var(--accent); box-shadow:0 0 0 3px rgba(109,94,252,.18)}
.field.bad input,.field.bad textarea{border-color:var(--err)}
.meta{display:flex; justify-content:space-between; gap:12px; margin-top:6px; font-size:11.5px; color:var(--muted)}
.count{font-variant-numeric:tabular-nums; white-space:nowrap}
.msg{color:var(--err); font-size:12px; margin-top:6px; font-weight:600}
.seg{display:flex; gap:8px}
.seg label{flex:1; position:relative}
.seg input{position:absolute; opacity:0; pointer-events:none}
.seg span{
  display:block; text-align:center; padding:10px 8px; border-radius:10px;
  border:1px solid var(--line); background:#0e121b; cursor:pointer;
  font-size:13px; font-weight:650; color:var(--muted); transition:.15s;
}
.seg input:checked + span{border-color:var(--accent); color:#fff; background:rgba(109,94,252,.16)}
.seg input:focus-visible + span{box-shadow:0 0 0 3px rgba(109,94,252,.25)}
.route label{flex:1}
.route span{text-align:left; line-height:1.35}
.route small{display:block; color:var(--muted); font-weight:500; font-size:11px; margin-top:3px}
.route input:checked + span small{color:#b9c0d4}
.filebox{
  display:flex; gap:14px; align-items:center; padding:14px;
  border:1.5px dashed var(--line); border-radius:12px; background:#0e121b;
  cursor:pointer; transition:.15s;
}
.filebox:hover{border-color:var(--accent); background:#101524}
.filebox input[type=file]{display:none}
.filebox .ic{
  width:42px; height:42px; flex:0 0 42px; border-radius:10px; display:grid; place-items:center;
  background:linear-gradient(135deg, rgba(109,94,252,.25), rgba(34,211,238,.15));
  border:1px solid var(--line); font-size:18px;
}
.filebox .t{font-size:13px; font-weight:650}
.filebox .s{font-size:11.5px; color:var(--muted); margin-top:2px}
.current{display:flex; align-items:center; gap:10px; margin-top:10px; font-size:12px; color:var(--muted)}
.current img{height:30px; width:auto; border-radius:6px; background:#0e121b; border:1px solid var(--line); padding:3px}
.alert{border-radius:11px; padding:12px 14px; font-size:13px; margin-bottom:18px; border:1px solid}
.alert.err{background:rgba(255,107,129,.09); border-color:rgba(255,107,129,.35); color:#ffc2cb}
.alert.warn{background:rgba(255,193,94,.08); border-color:rgba(255,193,94,.3); color:#ffdca0}
.alert.ok{background:rgba(45,212,167,.08); border-color:rgba(45,212,167,.3); color:#a9f3dd}
.actions{display:flex; gap:10px; align-items:center; margin-top:26px; flex-wrap:wrap}
.btn{
  appearance:none; border:1px solid transparent; border-radius:11px; cursor:pointer;
  padding:12px 22px; font:inherit; font-size:14px; font-weight:700; letter-spacing:.01em;
  transition:.15s; text-decoration:none; display:inline-flex; align-items:center; gap:8px;
}
.btn-primary{background:linear-gradient(135deg,var(--accent),#8b5cf6); color:#fff;
  box-shadow:0 16px 30px -18px var(--accent)}
.btn-primary:hover{filter:brightness(1.09); transform:translateY(-1px)}
.btn-ghost{background:transparent; border-color:var(--line); color:var(--muted)}
.btn-ghost:hover{color:var(--txt); border-color:#39425a}
.spacer{flex:1}
.summary{width:100%; border-collapse:collapse; font-size:13px}
.summary th,.summary td{padding:10px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top}
.summary th{color:var(--muted); font-weight:600; width:170px; font-size:12px; letter-spacing:.02em}
.summary td{word-break:break-word}
.summary tr:last-child th,.summary tr:last-child td{border-bottom:none}
.pill{display:inline-block; padding:2px 9px; border-radius:999px; font-size:11.5px; font-weight:700;
  border:1px solid var(--line); background:#0e121b; color:var(--muted)}
.pill.on{color:var(--ok); border-color:rgba(45,212,167,.35); background:rgba(45,212,167,.08)}
pre.code{
  margin:0; padding:16px; border-radius:12px; background:#0a0d13; border:1px solid var(--line);
  overflow:auto; max-height:340px; font-family:ui-monospace,SFMono-Regular,Menlo,monospace;
  font-size:12px; line-height:1.6; color:#c6cee0;
}
.footnote{margin:22px 0 0; text-align:center; font-size:11.5px; color:#4f586b; letter-spacing:.02em}
@media (max-width:560px){
  .card{padding:20px}
  .steps li{font-size:9.5px; letter-spacing:.06em; padding:8px 4px}
  .seg{flex-direction:column}
  .route{flex-direction:column}
}
</style>
</head>
<body>
<div class="aurora" aria-hidden="true"></div>
<main class="wrap">
  <header class="masthead">
    <div class="brand"><span class="spark"></span>AWFL<em>WIKI</em>WORLD</div>
    <span class="tag">setup wizard</span>
  </header>
  <ol class="steps">
    <?php foreach ($labels as $n => $lbl): ?>
      <li class="<?= $n === $step ? 'active' : ($n < $step ? 'done' : '') ?>"><?= h($lbl) ?></li>
    <?php endforeach; ?>
  </ol>
  <section class="card">
<?php
}

function ui_foot(): void
{
    ?>
  </section>
  <p class="footnote">AWFLWIKIWORLD · set.php · delete this file once your wiki is configured.</p>
</main>
<script>
(function () {
  document.querySelectorAll('[data-count]').forEach(function (el) {
    var target = document.getElementById(el.dataset.count);
    if (!target) return;
    var max = parseInt(el.dataset.max, 10) || 0;
    var upd = function () {
      var n = Array.from(target.value).length;
      el.textContent = n + ' / ' + max;
      el.classList.toggle('over', n > max);
    };
    target.addEventListener('input', upd);
    upd();
  });

  var logo = document.getElementById('Logo');
  if (logo) {
    logo.addEventListener('change', function () {
      var f = logo.files && logo.files[0];
      var nameEl = document.getElementById('logoName');
      if (nameEl) nameEl.textContent = f ? f.name : 'No file chosen — PNG, JPG, SVG, WEBP, GIF, ICO';
      if (f) {
        var img = document.getElementById('logoPreview');
        if (img) { img.src = URL.createObjectURL(f); img.style.display = 'block'; }
      }
    });
  }
})();
</script>
</body>
</html>
<?php
}

/* ============================================================
   Request handling
   ============================================================ */

$existing    = read_config_values($CONFIG);
$configThere = is_file($CONFIG);

$defaults = [
    'Sitename'         => (string)($existing['Sitename'] ?? ''),
    'MetaTitle'        => (string)($existing['MetaTitle'] ?? ''),
    'MetaDescription'  => (string)($existing['MetaDescription'] ?? ''),
    'Logo'             => (string)($existing['Logo'] ?? ''),
    'Username'         => (string)($existing['Username'] ?? ''),
    'Password'         => '',
    'ImageUpload'      => (($existing['ImageUpload'] ?? 'true') === 'true') ? 'true' : 'false',
    'ExternalImageUrl' => (($existing['ExternalImageUrl'] ?? 'true') === 'true') ? 'true' : 'false',
    'route'            => in_array(($existing['route'] ?? '0'), ['0', '1', '2'], true) ? (string)$existing['route'] : '0',
];

$server = trim((string)($existing['Server'] ?? ''));
if ($server === '' || $server === 'http://' || $server === 'https://') {
    $server = detect_server();
}
if ($server === '') {
    $server = 'http://localhost';
}

$mode   = (string)($_POST['step'] ?? 'form');
$errors = [];
$form   = $defaults;

/* ---------- Back to the form ---------- */
if ($mode === 'back') {
    $pending = $_SESSION['awfl_setup'] ?? null;
    if (is_array($pending) && isset($pending['values'])) {
        $form = array_merge($defaults, $pending['values']);
        $form['Logo'] = (string)($pending['logo'] ?? $form['Logo']);
    }
    unset($_SESSION['awfl_setup']);
    $mode = 'form';
}

/* ---------- Step 1 -> 2 : validate + stash ---------- */
if ($mode === 'preview') {
    $values = validate_fields($_POST, $errors);

    $logo = handle_logo_upload($_FILES['LogoFile'] ?? [], $LOGO_DIR, (string)$defaults['Logo'], $errors);
    if ($logo !== null) {
        $values['Logo'] = $logo;
    } else {
        $values['Logo'] = (string)$defaults['Logo'];
    }

    if ($errors) {
        $form = array_merge($defaults, $values, ['Password' => (string)($_POST['Password'] ?? '')]);
        $mode = 'form';
    } else {
        $token = bin2hex(random_bytes(16));
        $_SESSION['awfl_setup'] = [
            'token'  => $token,
            'values' => $values,
            'server' => $server,
            'logo'   => $values['Logo'],
        ];
        $mode = 'review';
    }
}

/* ---------- Step 2 -> 3 : write config.php ---------- */
if ($mode === 'write') {
    $pending = $_SESSION['awfl_setup'] ?? null;
    $token   = (string)($_POST['token'] ?? '');

    if (!is_array($pending) || !hash_equals((string)($pending['token'] ?? ''), $token)) {
        $errors['_'] = 'Your session expired. Please fill the form again.';
        $mode = 'form';
    } else {
        $values = $pending['values'];
        $server = (string)$pending['server'];

        [$baseSource, $fromExisting] = config_source($CONFIG, $AWFL_TEMPLATE);
        $missing = [];
        $newSource = build_config($baseSource, $values, $server, $missing);

        if ($newSource === null) {
            $errors['_'] = 'Could not generate the configuration (internal error).';
            $mode = 'form';
        } else {
            $backup = null;
            if ($configThere) {
                $backup = $CONFIG . '.bak';
                @copy($CONFIG, $backup);
            }

            $ok = @file_put_contents($CONFIG, $newSource, LOCK_EX);
            if ($ok === false) {
                $errors['_'] = 'config.php could not be written. Check the folder permissions.';
                $mode = 'form';
            } else {
                @chmod($CONFIG, 0644);
                unset($_SESSION['awfl_setup']);
                $mode = 'done';
            }
        }
    }
}

/* ============================================================
   Views
   ============================================================ */

if ($mode === 'done') {
    ui_head(3, 'Finished');
    ?>
    <h1>Configuration saved</h1>
    <p class="lede">
      <code>config.php</code> was generated next to <code>set.php</code>
      <?= $configThere ? '(existing file updated in place)' : '(new file created)' ?>.
    </p>

    <div class="alert ok">
      <strong>Success.</strong> Your wiki is now configured with
      <code>$Sitename = <?= h($values['Sitename']) ?></code> and
      <code>$Server = <?= h($server) ?></code>.
    </div>

    <?php if (!empty($backup) && is_file($backup)): ?>
      <div class="alert warn">
        A backup of the previous configuration was kept at <code>config.php.bak</code>.
      </div>
    <?php endif; ?>

    <?php if (!empty($missing)): ?>
      <div class="alert warn">
        These keys were not present in the old <code>config.php</code> and were appended:
        <?php foreach ($missing as $k): ?><code>$<?= h($k) ?></code> <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if (($values['route'] ?? '0') === '1' || ($values['route'] ?? '0') === '2'): ?>
      <div class="alert warn">
        You selected pretty URLs (route <code><?= h($values['route']) ?></code>).
        Make sure your <code>.htaccess</code> / rewrite rules are in place, otherwise
        links will 404.
      </div>
    <?php endif; ?>

    <div class="alert warn">
      <strong>Security:</strong> delete <code>set.php</code> now. While it exists,
      anybody who can reach it can overwrite your administrator credentials.
    </div>

    <div class="actions">
      <a class="btn btn-primary" href="index.php">Open the wiki →</a>
      <span class="spacer"></span>
      <a class="btn btn-ghost" href="set.php">Run setup again</a>
    </div>
    <?php
    ui_foot();
    exit;
}

if ($mode === 'review') {
    $pending      = $_SESSION['awfl_setup'];
    $values       = $pending['values'];
    $reviewServer = (string)$pending['server'];

    [$baseSource] = config_source($CONFIG, $AWFL_TEMPLATE);
    $masked = $values;
    $masked['Password'] = '********';
    $missing = [];
    $previewSource = build_config($baseSource, $masked, $reviewServer, $missing);
    if ($previewSource === null) {
        $previewSource = "// preview unavailable";
    }

    ui_head(2, 'Review');
    ?>
    <h1>Review your configuration</h1>
    <p class="lede">
      Nothing has been written yet. Check the values below, then press
      <strong>Continue</strong> to generate <code>config.php</code>.
    </p>

    <table class="summary">
      <tr><th>Sitename</th><td><?= h($values['Sitename']) ?></td></tr>
      <tr><th>MetaTitle</th><td><?= h($values['MetaTitle']) ?></td></tr>
      <tr><th>MetaDescription</th><td><?= h($values['MetaDescription']) ?></td></tr>
      <tr><th>Logo</th>
          <td>
            <?php if ($values['Logo'] !== ''): ?>
              <img src="<?= h($values['Logo']) ?>" alt="" style="height:34px;vertical-align:middle;margin-right:8px;border-radius:6px;border:1px solid var(--line);padding:2px;background:#0e121b">
            <?php endif; ?>
            <code><?= h($values['Logo']) ?></code>
          </td></tr>
      <tr><th>Username</th><td><code><?= h($values['Username']) ?></code></td></tr>
      <tr><th>Password</th><td><span class="pill">hidden — <?= slen((string)$values['Password']) ?> characters</span></td></tr>
      <tr><th>ImageUpload</th><td><span class="pill <?= $values['ImageUpload'] === 'true' ? 'on' : '' ?>"><?= h($values['ImageUpload']) ?></span></td></tr>
      <tr><th>ExternalImageUrl</th><td><span class="pill <?= $values['ExternalImageUrl'] === 'true' ? 'on' : '' ?>"><?= h($values['ExternalImageUrl']) ?></span></td></tr>
      <tr><th>route</th><td><code><?= h($values['route']) ?></code>
        <?php
          $routeHelp = ['0' => 'index.php?title=Pagename', '1' => '/Pagename', '2' => '/namespaces/Pagename'];
          echo ' — ' . h($routeHelp[$values['route']] ?? '');
        ?>
      </td></tr>
      <tr><th>$Server <span class="pill">auto</span></th><td><code><?= h($reviewServer) ?></code></td></tr>
      <tr><th>Target file</th><td><code><?= $configThere ? 'config.php (find &amp; replace)' : 'config.php (new file)' ?></code></td></tr>
    </table>

    <h2 style="font-size:14px;margin:26px 0 10px;color:var(--muted);letter-spacing:.05em;text-transform:uppercase">Resulting config.php</h2>
    <pre class="code"><?= h($previewSource) ?></pre>

    <form method="post" action="set.php">
      <input type="hidden" name="step" value="write">
      <input type="hidden" name="token" value="<?= h($pending['token']) ?>">
      <div class="actions">
        <button class="btn btn-primary" type="submit" name="confirm" value="1">Continue →</button>
        <button class="btn btn-ghost" type="submit" name="back" value="1" formnovalidate>← Back</button>
      </div>
    </form>
    <?php
    ui_foot();
    exit;
}

/* ---------- Step 1 : the form ---------- */
ui_head(1, 'Configure');
?>
<h1>Configure your wiki</h1>
<p class="lede">
  All nine fields are required. Submitting this form does not change anything yet —
  you will get a review screen first.
</p>

<?php if ($errors): ?>
  <div class="alert err">
    <strong>Please fix <?= count($errors) ?> field<?= count($errors) === 1 ? '' : 's' ?> below.</strong>
  </div>
<?php endif; ?>

<?php if ($configThere): ?>
  <div class="alert warn">
    An existing <code>config.php</code> was found. Its values are pre-filled and will be
    found &amp; replaced (a <code>config.php.bak</code> backup is kept).
  </div>
<?php endif; ?>

<form method="post" action="set.php" enctype="multipart/form-data" novalidate>

  <input type="hidden" name="step" value="preview">

  <div class="field <?= isset($errors['Sitename']) ? 'bad' : '' ?>">
    <label class="lbl" for="Sitename">Sitename <span class="req">*</span></label>
    <input type="text" id="Sitename" name="Sitename" maxlength="50" autocomplete="off"
           placeholder="My Wiki" value="<?= h($form['Sitename']) ?>" required>
    <div class="meta">
      <span>Shown in the header and page titles.</span>
      <span class="count" data-count="Sitename" data-max="50">0 / 50</span>
    </div>
    <?php if (isset($errors['Sitename'])): ?><div class="msg"><?= h($errors['Sitename']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['MetaTitle']) ? 'bad' : '' ?>">
    <label class="lbl" for="MetaTitle">MetaTitle <span class="req">*</span></label>
    <input type="text" id="MetaTitle" name="MetaTitle" maxlength="50" autocomplete="off"
           placeholder="My Wiki — the free encyclopedia" value="<?= h($form['MetaTitle']) ?>" required>
    <div class="meta">
      <span>Used for the browser tab and &lt;title&gt; tag.</span>
      <span class="count" data-count="MetaTitle" data-max="50">0 / 50</span>
    </div>
    <?php if (isset($errors['MetaTitle'])): ?><div class="msg"><?= h($errors['MetaTitle']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['MetaDescription']) ? 'bad' : '' ?>">
    <label class="lbl" for="MetaDescription">MetaDescription <span class="req">*</span></label>
    <textarea id="MetaDescription" name="MetaDescription" maxlength="160"
              placeholder="A short description of your wiki for search engines." required><?= h($form['MetaDescription']) ?></textarea>
    <div class="meta">
      <span>Shown in search-engine result snippets.</span>
      <span class="count" data-count="MetaDescription" data-max="160">0 / 160</span>
    </div>
    <?php if (isset($errors['MetaDescription'])): ?><div class="msg"><?= h($errors['MetaDescription']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['Logo']) ? 'bad' : '' ?>">
    <label class="lbl">Logo <span class="req">*</span></label>
    <label class="filebox" for="Logo">
      <span class="ic">🖼</span>
      <span>
        <span class="t">Choose an image…</span>
        <span class="s" id="logoName">No file chosen — PNG, JPG, SVG, WEBP, GIF, ICO (max 4 MB)</span>
      </span>
      <input type="file" id="Logo" name="LogoFile" accept="image/*,.svg,.ico">
    </label>
    <div class="current">
      <img id="logoPreview" alt="" style="display:none">
      <?php if ($form['Logo'] !== ''): ?>
        <span>Current: <code><?= h($form['Logo']) ?></code> — leave empty to keep it.</span>
      <?php else: ?>
        <span>The file is copied into <code>logo/</code> and referenced as <code>logo/your-file.ext</code>.</span>
      <?php endif; ?>
    </div>
    <?php if (isset($errors['Logo'])): ?><div class="msg"><?= h($errors['Logo']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['Username']) ? 'bad' : '' ?>">
    <label class="lbl" for="Username">Username <span class="req">*</span></label>
    <input type="text" id="Username" name="Username" autocomplete="off"
           placeholder="admin" value="<?= h($form['Username']) ?>" required>
    <div class="meta"><span>The administrator account name (at least 1 character).</span></div>
    <?php if (isset($errors['Username'])): ?><div class="msg"><?= h($errors['Username']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['Password']) ? 'bad' : '' ?>">
    <label class="lbl" for="Password">Password <span class="req">*</span></label>
    <input type="password" id="Password" name="Password" autocomplete="new-password"
           placeholder="••••••••" value="<?= h($form['Password']) ?>" required>
    <div class="meta"><span>At least 8 characters. Stored in config.php and hashed on first login.</span></div>
    <?php if (isset($errors['Password'])): ?><div class="msg"><?= h($errors['Password']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['ImageUpload']) ? 'bad' : '' ?>">
    <label class="lbl">ImageUpload <span class="req">*</span></label>
    <div class="seg">
      <label><input type="radio" name="ImageUpload" value="true" <?= $form['ImageUpload'] === 'true' ? 'checked' : '' ?>><span>true</span></label>
      <label><input type="radio" name="ImageUpload" value="false" <?= $form['ImageUpload'] === 'false' ? 'checked' : '' ?>><span>false</span></label>
    </div>
    <div class="meta"><span>Allow logged-in users to upload images.</span></div>
    <?php if (isset($errors['ImageUpload'])): ?><div class="msg"><?= h($errors['ImageUpload']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['ExternalImageUrl']) ? 'bad' : '' ?>">
    <label class="lbl">ExternalImageUrl <span class="req">*</span></label>
    <div class="seg">
      <label><input type="radio" name="ExternalImageUrl" value="true" <?= $form['ExternalImageUrl'] === 'true' ? 'checked' : '' ?>><span>true</span></label>
      <label><input type="radio" name="ExternalImageUrl" value="false" <?= $form['ExternalImageUrl'] === 'false' ? 'checked' : '' ?>><span>false</span></label>
    </div>
    <div class="meta"><span>Allow external image URLs (e.g. inside infoboxes).</span></div>
    <?php if (isset($errors['ExternalImageUrl'])): ?><div class="msg"><?= h($errors['ExternalImageUrl']) ?></div><?php endif; ?>
  </div>

  <div class="field <?= isset($errors['route']) ? 'bad' : '' ?>">
    <label class="lbl">route <span class="req">*</span></label>
    <div class="seg route">
      <label>
        <input type="radio" name="route" value="0" <?= $form['route'] === '0' ? 'checked' : '' ?>>
        <span>0 <small><code>index.php?title=Pagename</code></small></span>
      </label>
      <label>
        <input type="radio" name="route" value="1" <?= $form['route'] === '1' ? 'checked' : '' ?>>
        <span>1 <small><code>/Pagename</code> — pretty URLs, needs .htaccess</small></span>
      </label>
      <label>
        <input type="radio" name="route" value="2" <?= $form['route'] === '2' ? 'checked' : '' ?>>
        <span>2 <small><code>/namespaces/Pagename</code></small></span>
      </label>
    </div>
    <?php if (isset($errors['route'])): ?><div class="msg"><?= h($errors['route']) ?></div><?php endif; ?>
  </div>

  <div class="actions">
    <button class="btn btn-primary" type="submit">Continue →</button>
    <span class="spacer"></span>
    <span class="pill">$Server will be set to <?= h($server) ?></span>
  </div>
</form>
<?php
ui_foot();