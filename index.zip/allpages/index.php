<?php
require_once __DIR__ . '/../includes/functions.php';

// --- Scan namespaces including a/b/c/d/ ---
$baseDir = __DIR__ . '/../namespaces';
$pages = [];

if (is_dir($baseDir)) {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($baseDir, RecursiveDirectoryIterator::SKIP_DOTS)
    );
    foreach ($it as $file) {
        if ($file->isFile() && strtolower($file->getExtension()) === 'txt') {
            $rel = str_replace(DIRECTORY_SEPARATOR, '/', substr($file->getPathname(), strlen($baseDir) + 1));
            $slug = substr($rel, 0, -4); // a/b/c/d/Meta_AI
            if ($slug === '' || strtolower(basename($slug)) === 'index') continue;
            $display = str_replace('_', ' ', basename($slug));
            if (!isset($pages[$slug])) $pages[$slug] = $display;
        }
    }
}

$sort = ($_GET['sort'] ?? 'asc') === 'desc' ? 'desc' : 'asc';
if ($sort === 'asc') ksort($pages, SORT_NATURAL | SORT_FLAG_CASE);
else krsort($pages, SORT_NATURAL | SORT_FLAG_CASE);

// Route-proof URL using $Server/$route from functions.php/config.php
function awfl_allpages_url($slug){
    global $Server, $route;
    $Server = rtrim($Server ?? '', '/');
    $route = (string)($route ?? '0');
    $enc = implode('/', array_map('rawurlencode', explode('/', $slug)));
    if ($route === '0') return $Server . '/index.php?title=' . $enc;
    if ($route === '1') return $Server . '/index.php/' . $enc;
    if ($route === '2') return $Server . '/index.php/namespaces/' . $enc;
    return $Server . '/index.php?title=' . $enc;
}
$count = count($pages);

$pagename = 'All pages';
$headerMode = 'interface';
require __DIR__ . '/../includes/header.php';
?>
<main class="awfl-main">
    <h1>All pages</h1>
    <p>Showing <strong><?= $count ?></strong> pages — 
    <a href="?sort=asc">A-Z ↑</a> | <a href="?sort=desc">Z-A ↓</a></p>

    <div style="margin:14px 0;">
        <input type="search" id="pageSearch" placeholder="Search pages..." autocomplete="off" style="width:100%;padding:10px 14px;border:1px solid #c8ccd1;border-radius:20px;">
    </div>

    <table class="awfl-datatable">
        <thead><tr>
            <th>Page name</th><th>Path</th>
        </tr></thead>
        <tbody id="allpages-body">
        <?php foreach ($pages as $slug => $display): ?>
            <tr data-name="<?= htmlspecialchars(strtolower($display.' '.$slug)) ?>">
                <td><a href="<?= htmlspecialchars(awfl_allpages_url($slug)) ?>"><?= htmlspecialchars($display) ?></a></td>
                <td><small style="color:#72777d"><?= htmlspecialchars($slug) ?></small></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$pages): ?>
            <tr><td colspan="2"><em>No pages yet.</em></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</main>

<script>
const input = document.getElementById('pageSearch');
const rows = document.querySelectorAll('#allpages-body tr');
if(input){
  input.addEventListener('input', function(){
    const q = this.value.toLowerCase().trim();
    rows.forEach(tr=>{
      const name = tr.getAttribute('data-name') || '';
      tr.style.display = q==='' || name.includes(q) ? '' : 'none';
    });
  });
}
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>
















