<?php
require_once __DIR__ . '/../includes/functions.php';

$step = $_POST['step'] ?? 'find';
$error = '';
$foundUser = null;
$question = '';

if ($step === 'find' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lookup_username'])) {
    $u = awfl_find_user($_POST['lookup_username']);
    if ($u) {
        $question = $u['security_question'];
        $step = 'verify';
        $foundUser = $u['username'];
    } else {
        $error = 'No such username was found.';
        $step = 'find';
    }
}

if ($step === 'verify' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_username'])) {
    $u = awfl_find_user($_POST['verify_username']);
    if (!$u) {
        $error = 'That account could not be found.';
        $step = 'find';
    } elseif (strcasecmp($u['email'], trim($_POST['email'] ?? '')) !== 0) {
        $error = 'That email does not match our records.';
        $question = $u['security_question'];
        $foundUser = $u['username'];
        $step = 'verify';
    } elseif (!password_verify(strtolower(trim($_POST['security_answer'] ?? '')), $u['security_answer'])) {
        $error = 'That security answer is not correct.';
        $question = $u['security_question'];
        $foundUser = $u['username'];
        $step = 'verify';
    } else {
        // Verified — move to reset step.
        $_SESSION['awfl_recovery_verified'] = $u['username'];
        $step = 'reset';
        $foundUser = $u['username'];
    }
}

if ($step === 'reset' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'])) {
    $verifiedUser = $_SESSION['awfl_recovery_verified'] ?? null;
    if (!$verifiedUser) {
        $error = 'Your recovery session expired. Please start again.';
        $step = 'find';
    } elseif ($_POST['new_password'] !== $_POST['confirm_password']) {
        $error = 'Passwords do not match.';
        $foundUser = $verifiedUser;
        $step = 'reset';
    } elseif (strlen($_POST['new_password']) < 6) {
        $error = 'Password must be at least 6 characters.';
        $foundUser = $verifiedUser;
        $step = 'reset';
    } else {
        $users = awfl_load_users();
        foreach ($users as &$u) {
            if (strcasecmp($u['username'], $verifiedUser) === 0) {
                $u['password'] = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            }
        }
        unset($u);
        awfl_save_users($users);
        unset($_SESSION['awfl_recovery_verified']);
        $step = 'done';
    }
}

$pagename = 'Recover password'; $headerMode = 'interface';
require __DIR__ . '/../includes/header.php';
?>
<main class="awfl-main awfl-narrow">
    <h1>Recover password</h1>
    <?php if ($error): ?><p class="awfl-error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <?php if ($step === 'find'): ?>
        <p>Enter your username to begin.</p>
        <form method="post" class="awfl-form">
            <input type="hidden" name="step" value="find">
            <label>Username<br><input type="text" name="lookup_username" required autofocus></label>
            <button type="submit">Continue</button>
        </form>

    <?php elseif ($step === 'verify'): ?>
        <p>Security question: <strong><?= htmlspecialchars($question) ?></strong></p>
        <form method="post" class="awfl-form">
            <input type="hidden" name="step" value="verify">
            <input type="hidden" name="verify_username" value="<?= htmlspecialchars($foundUser) ?>">
            <label>Email used at registration<br><input type="email" name="email" required></label>
            <label>Security answer<br><input type="text" name="security_answer" required></label>
            <button type="submit">Verify</button>
        </form>

    <?php elseif ($step === 'reset'): ?>
        <p>Identity verified for <strong><?= htmlspecialchars($foundUser) ?></strong>. Set a new password below.</p>
        <form method="post" class="awfl-form">
            <input type="hidden" name="step" value="reset">
            <label>New password<br><input type="password" name="new_password" required></label>
            <label>Confirm new password<br><input type="password" name="confirm_password" required></label>
            <button type="submit">Set new password</button>
        </form>

    <?php elseif ($step === 'done'): ?>
        <p class="awfl-success">Your password has been changed successfully.</p>
        <p><a href="<?= htmlspecialchars(awfl_page_url_raw('Special:Login')) ?>">Go to log in</a></p>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>



















