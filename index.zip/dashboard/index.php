<?php
require_once __DIR__ . '/../includes/functions.php';
awfl_require_login();
awfl_require_admin();

define('AWFL_SETTINGS_FILE', __DIR__ . '/settings.json');

function awfl_load_settings(): array {
    if (!file_exists(AWFL_SETTINGS_FILE)) return ['skin' => 'vector2022', 'colors' => []];
    $d = json_decode(file_get_contents(AWFL_SETTINGS_FILE), true);
    return is_array($d) ? $d + ['skin' => 'vector2022', 'colors' => []] : ['skin' => 'vector2022', 'colors' => []];
}
function awfl_save_settings(array $s): void {
    file_put_contents(AWFL_SETTINGS_FILE, json_encode($s, JSON_PRETTY_PRINT));
}

$notice = ''; $error = '';
$settings = awfl_load_settings();
$tab = $_GET['tab'] ?? 'skins';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'set_skin') {
        $skin = basename($_POST['skin'] ?? 'vector2022');
        if (file_exists(AWFL_SKINS_DIR . '/' . $skin . '.css')) {
            $settings['skin'] = $skin;
            awfl_save_settings($settings);
            $notice = "Active skin set to \"$skin\".";
        } else {
            $error = 'That skin does not exist.';
        }
        $tab = 'skins';

    } elseif ($formAction === 'create_skin') {
        $name = preg_replace('/[^A-Za-z0-9_\-]/', '', $_POST['skin_name'] ?? '');
        if ($name === '' || strcasecmp($name, 'vector2022') === 0) {
            $error = 'Choose a different skin name (vector2022 is reserved).';
        } elseif (file_exists(AWFL_SKINS_DIR . '/' . $name . '.css')) {
            $error = 'A skin with that name already exists.';
        } else {
            file_put_contents(AWFL_SKINS_DIR . '/' . $name . '.css', $_POST['skin_css'] ?? "/* $name skin */\n");
            $notice = "Skin \"$name\" created.";
        }
        $tab = 'skins';

    } elseif ($formAction === 'edit_skin') {
        $name = basename($_POST['skin_name'] ?? '');
        if ($name === 'vector2022') {
            $error = 'The default skin cannot be edited — create a new skin instead.';
        } elseif (!file_exists(AWFL_SKINS_DIR . '/' . $name . '.css')) {
            $error = 'Skin not found.';
        } else {
            file_put_contents(AWFL_SKINS_DIR . '/' . $name . '.css', $_POST['skin_css'] ?? '');
            $notice = "Skin \"$name\" updated.";
        }
        $tab = 'skins';

    } elseif ($formAction === 'set_colors') {
        $colors = [];
        foreach (array_keys(awfl_color_fields()) as $key) {
            $val = trim($_POST['color_' . $key] ?? '');
            if ($val !== '' && preg_match('/^#[0-9a-fA-F]{6}$/', $val)) $colors[$key] = $val;
        }
        $settings['colors'] = $colors;
        awfl_save_settings($settings);
        $notice = 'Color palette updated.';
        $tab = 'colors';

    } elseif ($formAction === 'delete_page') {
        awfl_delete_page($_POST['page_title'] ?? '');
        $notice = 'Page deleted.';
        $tab = 'pages';

    } elseif ($formAction === 'delete_all_pages') {
        foreach (awfl_list_pages() as $p) awfl_delete_page($p);
        $notice = 'All pages deleted.';
        $tab = 'pages';

    } elseif ($formAction === 'delete_image') {
        $img = basename($_POST['image_name'] ?? '');
        $path = AWFL_IMAGES_DIR . '/' . $img;
        if (file_exists($path)) { unlink($path); $notice = "Image \"$img\" deleted."; }
        $tab = 'images';
    }
}

$pagename = 'Dashboard';
$headerMode = 'interface';
require __DIR__ . '/../includes/header.php';
?>
<main class="awfl-main">
    <h1>Admin dashboard</h1>
    <?php if ($notice): ?><p class="awfl-success"><?= htmlspecialchars($notice) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="awfl-error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <nav class="awfl-editor-toolbar" style="margin-bottom:20px;">
        <a href="?tab=skins"><button type="button" class="awfl-tab <?= $tab === 'skins' ? 'active' : '' ?>">Skins</button></a>
        <a href="?tab=colors"><button type="button" class="awfl-tab <?= $tab === 'colors' ? 'active' : '' ?>">Colors</button></a>
        <a href="?tab=pages"><button type="button" class="awfl-tab <?= $tab === 'pages' ? 'active' : '' ?>">Pages</button></a>
        <a href="?tab=images"><button type="button" class="awfl-tab <?= $tab === 'images' ? 'active' : '' ?>">Images</button></a>
        <a href="../allusers/index.php"><button type="button" class="awfl-tab">Users</button></a>


        <a href="namespaces.php"><button type="button" class="awfl-tab">Namespaces</button></a>

        <a href="https://aedtpworld.com/wikiworld/AWFLWIKIWORLD/AWFLWIKIWORLD"><button type="button" class="awfl-tab">AWFLWIKIWORLD</button></a>


    </nav>

    <?php if ($tab === 'skins'): $skins = awfl_list_skins(); ?>
        <h2>Skins</h2>
        <p>Applies to the whole system. The default <code>vector2022</code> skin cannot be deleted or edited — create your own skin to customize freely.</p>
        <form method="post" class="awfl-form" style="max-width:400px;">
            <input type="hidden" name="form_action" value="set_skin">
            <label>Active skin<br>
                <select name="skin">
                    <?php foreach ($skins as $s): ?>
                        <option value="<?= htmlspecialchars($s) ?>" <?= $settings['skin'] === $s ? 'selected' : '' ?>><?= htmlspecialchars($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button type="submit">Set active skin</button>
        </form>

        <h3>Create a new skin</h3>
        <form method="post" class="awfl-form">
            <input type="hidden" name="form_action" value="create_skin">
            <label>Skin name<br><input type="text" name="skin_name" placeholder="e.g. midnight" required></label>
            <label>CSS<br><textarea name="skin_css" rows="10" placeholder=":root { --awfl-header-bg: #111; }"></textarea></label>
            <button type="submit">Create skin</button>
        </form>

        <h3>Edit an existing custom skin</h3>
        <form method="post" class="awfl-form">
            <input type="hidden" name="form_action" value="edit_skin">
            <label>Skin<br>
                <select name="skin_name">
                    <?php foreach ($skins as $s): if ($s === 'vector2022') continue; ?>
                        <option value="<?= htmlspecialchars($s) ?>"><?= htmlspecialchars($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>CSS content (paste the full file content to overwrite)<br><textarea name="skin_css" rows="10"></textarea></label>
            <button type="submit">Save skin</button>
        </form>

    <?php elseif ($tab === 'colors'): ?>
        <h2>Color palette</h2>
        <p>Pick a color or type a hex code for each element. Applies across the whole system.</p>
        <form method="post" class="awfl-form">
            <input type="hidden" name="form_action" value="set_colors">
            <?php foreach (awfl_color_fields() as $key => [$cssVar, $label]): $val = $settings['colors'][$key] ?? ''; ?>
            <div class="awfl-color-row">
                <label><?= htmlspecialchars($label) ?>:</label>
                <input type="color" value="<?= htmlspecialchars($val ?: '#202122') ?>">
                <input type="text" name="color_<?= htmlspecialchars($key) ?>" value="<?= htmlspecialchars($val) ?>" placeholder="#rrggbb">
            </div>
            <?php endforeach; ?>
            <button type="submit">Save colors</button>
        </form>

    <?php elseif ($tab === 'pages'): $pages = awfl_list_pages(); ?>
        <h2>Pages</h2>
        <p><a href="../sitemap/sitemap.php" target="_blank">Regenerate sitemap</a> (splits into ≤1MB files automatically and updates robots.txt)</p>
        <form method="post" onsubmit="return confirm('Delete ALL wiki pages? This cannot be undone.');" style="margin-bottom:16px;">
            <input type="hidden" name="form_action" value="delete_all_pages">
            <button type="submit" class="awfl-danger">Delete all pages</button>
        </form>
        <table class="awfl-datatable">
            <thead><tr><th>Page</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($pages as $p): ?>
                <tr>
                    <td><a href="<?= htmlspecialchars(awfl_page_url_raw($p)) ?>"><?= htmlspecialchars($p) ?></a></td>
                    <td>
                        <form method="post" style="display:inline" onsubmit="return confirm('Delete this page?');">
                            <input type="hidden" name="form_action" value="delete_page">
                            <input type="hidden" name="page_title" value="<?= htmlspecialchars($p) ?>">
                            <button type="submit" class="awfl-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$pages): ?><tr><td colspan="2"><em>No pages yet.</em></td></tr><?php endif; ?>
            </tbody>
        </table>

    <?php elseif ($tab === 'images'): $images = glob(AWFL_IMAGES_DIR . '/*.{jpg,jpeg,png,JPG,JPEG,PNG}', GLOB_BRACE) ?: []; ?>
        <h2>Uploaded images</h2>
        <table class="awfl-datatable">
            <thead><tr><th>Preview</th><th>Filename</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($images as $imgPath): $imgName = basename($imgPath); ?>
                <tr>
                    <td><img src="<?= htmlspecialchars(awfl_asset_url('images/' . $imgName)) ?>" style="width:60px;height:auto;"></td>
                    <td><?= htmlspecialchars($imgName) ?></td>
                    <td>
                        <form method="post" style="display:inline" onsubmit="return confirm('Delete this image?');">
                            <input type="hidden" name="form_action" value="delete_image">
                            <input type="hidden" name="image_name" value="<?= htmlspecialchars($imgName) ?>">
                            <button type="submit" class="awfl-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$images): ?><tr><td colspan="3"><em>No images uploaded yet.</em></td></tr><?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
















