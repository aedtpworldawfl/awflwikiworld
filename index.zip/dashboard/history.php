<?php
require_once __DIR__ . '/../includes/functions.php';
awfl_require_login();
awfl_require_admin();

$notice = ''; $error = '';
$sort = $_GET['sort'] ?? 'date';
$dir  = ($_GET['dir'] ?? 'desc') === 'asc' ? 'asc' : 'desc';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formAction = $_POST['form_action'] ?? '';
    $selectedIdx = array_map('intval', $_POST['selected'] ?? []);
    $entries = awfl_load_history();

    if ($formAction === 'delete_selected') {
        $keep = [];
        foreach ($entries as $i => $e) {
            if (!in_array($i, $selectedIdx, true)) $keep[] = $e;
        }
        awfl_save_history($keep);
        $notice = (count($entries) - count($keep)) . ' history record(s) deleted.';
        $entries = $keep;

    } elseif ($formAction === 'restore_selected') {
        $count = 0;
        foreach ($selectedIdx as $i) {
            if (!isset($entries[$i])) continue;
            $e = $entries[$i];
            $title = $e['namespace'] !== '' ? ($e['namespace'] . '/' . preg_replace('/\.txt$/', '', $e['filename'])) : preg_replace('/\.txt$/', '', $e['filename']);
            $title = awfl_urlform_to_title($title);
            awfl_save_page($title, $e['content']);
            $count++;
        }
        $notice = "$count page(s) restored from history.";
    }
}

$entries = awfl_load_history();
usort($entries, function ($a, $b) use ($sort) {
    $valA = $a[$sort] ?? '';
    $valB = $b[$sort] ?? '';
    return $valA <=> $valB;
});
if ($dir === 'desc') $entries = array_reverse($entries);

function awfl_history_sort_link(string $col, string $label, string $sort, string $dir): string {
    $newDir = ($sort === $col && $dir === 'asc') ? 'desc' : 'asc';
    $arrow = $sort === $col ? ($dir === 'asc' ? ' ▲' : ' ▼') : '';
    return '<a href="?sort=' . urlencode($col) . '&dir=' . urlencode($newDir) . '">' . htmlspecialchars($label) . $arrow . '</a>';
}

$pagename = 'Edit history';
$headerMode = 'interface';
require __DIR__ . '/../includes/header.php';
?>
<main class="awfl-main">
    <h1>Admin edit history</h1>
    <p>Only the <strong>latest</strong> admin edit of each page is kept here (no duplicates). Restoring writes the saved content straight back to the live page.</p>
    <?php if ($notice): ?><p class="awfl-success"><?= htmlspecialchars($notice) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="awfl-error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <form method="post">
        <div class="awfl-editor-toolbar" style="margin-bottom:10px;">
            <button type="submit" name="form_action" value="delete_selected" class="awfl-danger" onclick="return confirm('Delete the selected history record(s)? This cannot be undone.');">Delete selected</button>
            <button type="submit" name="form_action" value="restore_selected" onclick="return confirm('Restore the selected page(s) to this saved content? This overwrites the current live page.');">Restore selected</button>
        </div>
        <table class="awfl-datatable">
            <thead>
                <tr>
                    <th><input type="checkbox" onclick="document.querySelectorAll('.awfl-hist-check').forEach(c=>c.checked=this.checked)"></th>
                    <th><?= awfl_history_sort_link('pagename', 'Page name', $sort, $dir) ?></th>
                    <th><?= awfl_history_sort_link('filename', 'File name', $sort, $dir) ?></th>
                    <th><?= awfl_history_sort_link('namespace', 'Namespace', $sort, $dir) ?></th>
                    <th><?= awfl_history_sort_link('date', 'Date', $sort, $dir) ?></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($entries as $i => $e): ?>
                <tr>
                    <td>
                        <input type="checkbox" class="awfl-hist-check" name="selected[]" value="<?= $i ?>">
                    </td>
                    <td><?= htmlspecialchars($e['pagename']) ?></td>
                    <td><?= htmlspecialchars($e['filename']) ?></td>
                    <td><?= htmlspecialchars($e['namespace'] !== '' ? $e['namespace'] : '—') ?></td>
                    <td><?= htmlspecialchars(str_replace('T', ' ', substr($e['date'], 0, 16))) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$entries): ?><tr><td colspan="5"><em>No admin edits recorded yet.</em></td></tr><?php endif; ?>
            </tbody>
        </table>
    </form>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
















