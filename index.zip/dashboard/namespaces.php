<?php
require_once __DIR__. '/../includes/functions.php';

// --- FIX: If not admin, redirect to a.com/b/ = wikiworld/ ---
if (!awfl_is_admin()) {
    header('Location:../');
    exit;
}

$baseDir = __DIR__. '/../namespaces';
if (!is_dir($baseDir)) mkdir($baseDir, 0755, true);
$realBase = realpath($baseDir)?: $baseDir;

$notice = '';
$error = '';

function awfl_valid_ns($s){
    return preg_match('#^[A-Za-z0-9_\-\(\)]+(/[A-Za-z0-9_\-\(\)]+)*$#', $s);
}
function awfl_list_ns($base){
    $out = [];
    if(!is_dir($base)) return $out;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($base, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach($it as $f){
        if($f->isDir()){
            $rel = str_replace(DIRECTORY_SEPARATOR, '/', substr($f->getPathname(), strlen($base)+1));
            if($rel!== '') $out[] = $rel;
        }
    }
    sort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}
function awfl_rmdir_recursive($path){
    $it = new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS);
    $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
    foreach($files as $file){ $file->isDir()? rmdir($file->getRealPath()) : unlink($file->getRealPath()); }
    rmdir($path);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['ns_action']?? '';

    if ($act === 'create') {
        $ns = trim($_POST['new_ns']?? '', '/');
        if (!awfl_valid_ns($ns)) $error = 'Invalid namespace. Use A-Z 0-9 _ - ( ) and /. Eg: a/b/c/d';
        else {
            $path = $realBase. '/'. $ns;
            if (is_dir($path)) $error = "Namespace '$ns' already exists.";
            elseif (!mkdir($path, 0755, true)) $error = "Failed to create '$ns'.";
            else $notice = "Namespace '$ns' created.";
        }
    } elseif ($act === 'delete_selected') {
        $selected = $_POST['selected']?? [];
        $force =!empty($_POST['force']);
        if (!$selected) $error = 'No namespace selected.';
        else {
            $deleted = 0;
            foreach($selected as $ns){
                $ns = trim($ns, '/');
                if(!awfl_valid_ns($ns)) continue;
                $path = $realBase. '/'. $ns;
                if(!is_dir($path)) continue;
                if(!$force){
                    $hasFile = false;
                    $rit = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS));
                    foreach($rit as $f){ if($f->isFile()){ $hasFile=true; break; } }
                    if($hasFile){ $error.= "Skip '$ns' has pages. Tick Force to delete. "; continue; }
                }
                awfl_rmdir_recursive($path);
                $deleted++;
            }
            if($deleted) $notice = "$deleted namespace(s) deleted.";
        }
    } elseif ($act === 'rename_selected') {
        $selected = $_POST['selected']?? [];
        $new = trim($_POST['rename_to']?? '', '/');
        if (count($selected)!== 1) $error = 'Select exactly ONE namespace to rename.';
        elseif (!awfl_valid_ns($new)) $error = 'Invalid new name. Eg: x/y';
        else {
            $old = trim($selected[0], '/');
            if (!awfl_valid_ns($old)) $error = 'Invalid selection.';
            else {
                $oldPath = $realBase. '/'. $old;
                $newPath = $realBase. '/'. $new;
                if (!is_dir($oldPath)) $error = "Source '$old' not found.";
                elseif (is_dir($newPath)) $error = "Target '$new' already exists.";
                elseif (!rename($oldPath, $newPath)) $error = "Failed to rename '$old'.";
                else $notice = "Renamed '$old' → '$new'.";
            }
        }
    }
}

$namespaces = awfl_list_ns($realBase);
$pagename = 'Namespaces';
$headerMode = 'interface';
require __DIR__. '/../includes/header.php';
?>
<main class="awfl-main">
    <h1>Namespaces</h1>
    <p>Listing only folders in <code>../namespaces/</code> — Select to manage.</p>
    <?php if ($notice):?><p class="awfl-success"><?= htmlspecialchars($notice)?></p><?php endif;?>
    <?php if ($error):?><p class="awfl-error"><?= htmlspecialchars($error)?></p><?php endif;?>

    <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;margin:16px 0;">
        <input type="hidden" name="ns_action" value="create">
        <input type="text" name="new_ns" placeholder="Add new namespace e.g. a/b/c/d" required style="flex:1;min-width:220px;padding:10px;border:1px solid #c8ccd1;border-radius:6px;">
        <button type="submit">Add</button>
    </form>

    <form method="post" id="nsForm">
    <table class="awfl-datatable">
        <thead><tr>
            <th><input type="checkbox" id="selectAll"></th>
            <th>Folder / Subfolder</th>
        </tr></thead>
        <tbody>
        <?php foreach ($namespaces as $ns):?>
            <tr>
                <td><input type="checkbox" name="selected[]" value="<?= htmlspecialchars($ns)?>" class="nsCheck"></td>
                <td><?= htmlspecialchars($ns)?></td>
            </tr>
        <?php endforeach;?>
        <?php if (!$namespaces):?>
            <tr><td colspan="2"><em>No namespaces yet. Add one above.</em></td></tr>
        <?php endif;?>
        </tbody>
    </table>

    <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
        <label><input type="checkbox" name="force" value="1"> Force delete with pages</label>
        <input type="text" name="rename_to" placeholder="New name for rename (select one)" style="padding:8px;border:1px solid #c8ccd1;border-radius:6px;min-width:220px;">
        <button type="submit" name="ns_action" value="delete_selected" class="awfl-danger" onclick="return confirm('Delete selected namespaces?');">Delete</button>
        <button type="submit" name="ns_action" value="rename_selected">Rename</button>
    </div>
    </form>

    <p style="margin-top:18px"><a href="./">← Dashboard</a></p>
</main>

<script>
document.getElementById('selectAll')?.addEventListener('change', function(){
    document.querySelectorAll('.nsCheck').forEach(c=>c.checked=this.checked);
});
</script>

<?php require __DIR__. '/../includes/footer.php';?>
















