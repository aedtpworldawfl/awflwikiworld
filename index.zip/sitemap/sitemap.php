<?php
/**
 * sitemap/sitemap.php
 *
 * Generates namespaces/pages sitemap XML files, auto-splitting into
 * sitemap-1.xml, sitemap-2.xml, ... whenever a chunk would exceed ~1MB,
 * and writes sitemap.xml as a <sitemapindex> that lists every split.
 *
 * Because search engines crawl a sitemap index and then follow every
 * <sitemap> entry inside it on their own, submitting the single
 * sitemap.xml URL once (in Search Console, or via robots.txt below) is
 * enough for bots to discover all current and future splits without
 * resubmitting each one by hand.
 *
 * Can be run from the CLI (cron) or requested by an admin from the
 * dashboard / directly in a browser while logged in as admin.
 */

require_once __DIR__ . '/../includes/functions.php';

// Allow CLI (cron) use without an HTTP session/admin check.
$isCli = (php_sapi_name() === 'cli');
if (!$isCli) {
    awfl_require_login();
    awfl_require_admin();
}

const AWFL_SITEMAP_MAX_BYTES = 1_000_000; // ~1MB per split, safely under Google's 50MB/50k-URL cap

function awfl_url_entry(string $loc, string $lastmod): string {
    return "  <url>\n    <loc>" . htmlspecialchars($loc, ENT_XML1) . "</loc>\n    <lastmod>" . $lastmod . "</lastmod>\n  </url>\n";
}

function awfl_generate_sitemap(): array {
    $pages = awfl_list_pages();
    $header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    $footer = "</urlset>\n";

    $splits = [];
    $currentBody = '';
    $currentSize = strlen($header) + strlen($footer);

    foreach ($pages as $title) {
        $path = awfl_page_filepath($title);
        $lastmod = date('c', file_exists($path) ? filemtime($path) : time());
        $entry = awfl_url_entry(awfl_page_url_raw($title), $lastmod);

        if ($currentSize + strlen($entry) > AWFL_SITEMAP_MAX_BYTES && $currentBody !== '') {
            $splits[] = $header . $currentBody . $footer;
            $currentBody = '';
            $currentSize = strlen($header) + strlen($footer);
        }
        $currentBody .= $entry;
        $currentSize += strlen($entry);
    }
    if ($currentBody !== '' || empty($splits)) {
        $splits[] = $header . $currentBody . $footer;
    }

    // Write splits: sitemap-1.xml, sitemap-2.xml, ...
    $dir = __DIR__;
    foreach (glob($dir . '/sitemap-*.xml') as $old) unlink($old); // clear stale splits
    $urls = [];
    foreach ($splits as $i => $xml) {
        $n = $i + 1;
        $filename = "sitemap-$n.xml";
        file_put_contents($dir . '/' . $filename, $xml);
        $urls[] = awfl_asset_url("sitemap/$filename");
    }

    // Write the sitemap index.
    $indexBody = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
    $now = date('c');
    foreach ($urls as $u) {
        $indexBody .= "  <sitemap>\n    <loc>" . htmlspecialchars($u, ENT_XML1) . "</loc>\n    <lastmod>$now</lastmod>\n  </sitemap>\n";
    }
    $indexBody .= "</sitemapindex>\n";
    file_put_contents($dir . '/sitemap.xml', $indexBody);

    // Make sure bots that only ever check robots.txt can find the index once.
    $robotsPath = dirname(__DIR__) . '/robots.txt';
    $sitemapUrl = awfl_asset_url('sitemap/sitemap.xml');
    $robotsBody = "User-agent: *\nAllow: /\n\nSitemap: $sitemapUrl\n";
    file_put_contents($robotsPath, $robotsBody);

    return ['pages' => count($pages), 'splits' => count($splits), 'index' => $dir . '/sitemap.xml'];
}

$result = awfl_generate_sitemap();

if ($isCli) {
    echo "Sitemap generated: {$result['pages']} pages across {$result['splits']} split file(s).\n";
} else {
    header('Content-Type: text/plain; charset=utf-8');
    echo "Sitemap generated.\n";
    echo "Pages: {$result['pages']}\n";
    echo "Split files: {$result['splits']}\n";
    echo "Index: sitemap/sitemap.xml\n";
}



















