<?php
require_once __DIR__ . '/../includes/functions.php';

$isAdmin = awfl_is_admin();
$view = ($_GET['view'] ?? 'grid') === 'detail' ? 'detail' : 'grid';
$bucket = ($isAdmin && ($_GET['bucket'] ?? 'active') === 'trash') ? 'trash' : 'active';
$sort = $_GET['sort'] ?? 'name';
$dir  = ($_GET['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';

$notice = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    awfl_require_login();
    awfl_require_admin();
    $formAction = $_POST['form_action'] ?? '';
    $selectedIdx = array_map('intval', $_POST['selected'] ?? []);

    if ($formAction === 'delete_selected') {
        $files = $_POST['file'] ?? [];
        $count = 0;
        foreach ($selectedIdx as $i) {
            if (isset($files[$i]) && awfl_move_image_to_trash($files[$i])) $count++;
        }
        $notice = "$count image(s) moved to trash.";
    } elseif ($formAction === 'restore_selected') {
        $files = $_POST['file'] ?? [];
        $count = 0;
        foreach ($selectedIdx as $i) {
            if (isset($files[$i]) && awfl_restore_image_from_trash($files[$i])) $count++;
        }
        $notice = "$count image(s) restored.";
    } elseif ($formAction === 'rename_selected') {
        $files = $_POST['file'] ?? [];
        $newnames = $_POST['newname'] ?? [];
        $count = 0; $failures = [];
        foreach ($selectedIdx as $i) {
            if (!isset($files[$i]) || !isset($newnames[$i]) || trim($newnames[$i]) === '') continue;
            [$ok, $msg] = awfl_rename_image($files[$i], $newnames[$i], $bucket);
            if ($ok) $count++; else $failures[] = "{$files[$i]}: $msg";
        }
        $notice = "$count image(s) renamed.";
        if ($failures) $error = implode(' ', $failures);
    }
}

$images = awfl_list_image_files($bucket);
$images = awfl_sort_images($images, $sort, $dir);

function awfl_images_sort_link(string $col, string $label, string $view, string $bucket, string $sort, string $dir): string {
    $newDir = ($sort === $col && $dir === 'asc') ? 'desc' : 'asc';
    $arrow = $sort === $col ? ($dir === 'asc' ? ' ▲' : ' ▼') : '';
    $url = '?view=' . urlencode($view) . '&bucket=' . urlencode($bucket) . '&sort=' . urlencode($col) . '&dir=' . urlencode($newDir);
    return '<a href="' . htmlspecialchars($url) . '">' . htmlspecialchars($label) . $arrow . '</a>';
}

$pagename = 'All images';
$headerMode = 'interface';
require __DIR__ . '/../includes/header.php';
?>
<main class="awfl-main">
    <h1>All images</h1>
    <?php if ($notice): ?><p class="awfl-success"><?= htmlspecialchars($notice) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="awfl-error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <nav class="awfl-editor-toolbar" style="margin-bottom:16px;">
        <a href="?view=grid&bucket=<?= htmlspecialchars($bucket) ?>"><button type="button" class="awfl-tab <?= $view === 'grid' ? 'active' : '' ?>">Content view</button></a>
        <a href="?view=detail&bucket=<?= htmlspecialchars($bucket) ?>"><button type="button" class="awfl-tab <?= $view === 'detail' ? 'active' : '' ?>">Detail view</button></a>
        <?php if ($isAdmin): ?>
            <span class="awfl-toolbar-sep"></span>
            <a href="?view=<?= htmlspecialchars($view) ?>&bucket=active"><button type="button" class="awfl-tab <?= $bucket === 'active' ? 'active' : '' ?>">Active</button></a>
            <a href="?view=<?= htmlspecialchars($view) ?>&bucket=trash"><button type="button" class="awfl-tab <?= $bucket === 'trash' ? 'active' : '' ?>">Deleted</button></a>
        <?php endif; ?>
    </nav>

    <?php if ($view === 'grid'): ?>
        <div class="awfl-image-grid">
        <?php foreach ($images as $img): $url = awfl_asset_url(($bucket === 'trash' ? 'images/trash/' : 'images/') . $img['name']); ?>
            <div class="awfl-image-cell">
                <img src="<?= htmlspecialchars($url) ?>" alt="<?= htmlspecialchars($img['name']) ?>" loading="lazy">
                <div class="awfl-image-name" title="<?= htmlspecialchars($img['name']) ?>"><?= htmlspecialchars($img['name']) ?></div>
                <div class="awfl-image-cell-actions">
                    <button type="button" class="awfl-copy-btn" data-copy="<?= htmlspecialchars($url) ?>">Copy link</button>
                    <button type="button" class="awfl-copy-btn" data-copy="<?= htmlspecialchars($img['name']) ?>">Copy name</button>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (!$images): ?><p><em>No images here.</em></p><?php endif; ?>
        </div>

    <?php else: ?>
        <form method="post" id="awfl-images-form">
            <?php if ($isAdmin): ?>
            <div class="awfl-editor-toolbar" style="margin-bottom:10px;">
                <?php if ($bucket === 'active'): ?>
                    <button type="submit" name="form_action" value="delete_selected" class="awfl-danger" onclick="return confirm('Move selected images to trash?');">Delete selected</button>
                <?php else: ?>
                    <button type="submit" name="form_action" value="restore_selected" onclick="return confirm('Restore selected images?');">Restore selected</button>
                <?php endif; ?>
                <button type="submit" name="form_action" value="rename_selected" onclick="return confirm('Rename the selected image(s) using the names typed in the boxes?');">Rename selected</button>
            </div>
            <?php endif; ?>
            <table class="awfl-datatable">
                <thead>
                    <tr>
                        <?php if ($isAdmin): ?><th><input type="checkbox" onclick="document.querySelectorAll('.awfl-img-check').forEach(c=>c.checked=this.checked)"></th><?php endif; ?>
                        <th><?= awfl_images_sort_link('name', 'File name', $view, $bucket, $sort, $dir) ?></th>
                        <th><?= awfl_images_sort_link('ext', 'Extension', $view, $bucket, $sort, $dir) ?></th>
                        <th><?= awfl_images_sort_link('size', 'File size', $view, $bucket, $sort, $dir) ?></th>
                        <th><?= awfl_images_sort_link('mtime', 'Upload date', $view, $bucket, $sort, $dir) ?></th>
                        <?php if ($isAdmin): ?><th>Rename to</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($images as $i => $img): ?>
                    <tr>
                        <?php if ($isAdmin): ?>
                        <td>
                            <input type="checkbox" class="awfl-img-check" name="selected[]" value="<?= $i ?>">
                            <input type="hidden" name="file[<?= $i ?>]" value="<?= htmlspecialchars($img['name']) ?>">
                        </td>
                        <?php endif; ?>
                        <td><?= htmlspecialchars($img['name']) ?></td>
                        <td><?= htmlspecialchars($img['ext']) ?></td>
                        <td><?= htmlspecialchars(awfl_human_filesize($img['size'])) ?></td>
                        <td><?= htmlspecialchars(date('Y-m-d H:i', $img['mtime'])) ?></td>
                        <?php if ($isAdmin): ?>
                        <td><input type="text" name="newname[<?= $i ?>]" placeholder="<?= htmlspecialchars(pathinfo($img['name'], PATHINFO_FILENAME)) ?>" style="width:140px;"></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$images): ?><tr><td colspan="<?= $isAdmin ? 6 : 4 ?>"><em>No images here.</em></td></tr><?php endif; ?>
                </tbody>
            </table>
        </form>
    <?php endif; ?>
</main>
<script>
document.querySelectorAll('.awfl-copy-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
        navigator.clipboard.writeText(btn.getAttribute('data-copy')).then(function () {
            var old = btn.textContent;
            btn.textContent = 'Copied!';
            setTimeout(function () { btn.textContent = old; }, 1200);
        });
    });
});
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
















