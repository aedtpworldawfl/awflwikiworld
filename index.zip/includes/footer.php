<?php $currentUser = $currentUser ?? awfl_current_user(); ?>
    </div><!-- /.awfl-body -->
    <footer class="awfl-footer">
        <div class="awfl-footer-inner">
            <a class="awfl-powered" href="<?= htmlspecialchars($Server) ?>">
                <img src="<?= htmlspecialchars(awfl_asset_url($Logo)) ?>" alt="Powered by <?= htmlspecialchars($Sitename) ?>">
                <span>Powered by <?= htmlspecialchars($Sitename) ?></span>
            </a>
                       <div class="awfl-footer-links">
<?php if ($currentUser): ?>
                <span>Logged in as <strong><?= htmlspecialchars($currentUser['name']) ?></strong></span> 
                <a href="<?= htmlspecialchars(awfl_asset_url('index.php?action=logout')) ?>"><button type="button" class="awfl-ftab">Log out</button></a> 
<?php else: ?>
                <a href="<?= htmlspecialchars(awfl_asset_url('index.php?title=Special:Login')) ?>"><button type="button" class="awfl-ftab">Log in</button></a>
<?php endif; ?>

                <a href="<?= htmlspecialchars(awfl_asset_url('allusers/index.php')) ?>"><button type="button" class="awfl-ftab">All users</button></a>
                <a href="<?= htmlspecialchars(awfl_asset_url('sitemap/sitemap.xml')) ?>"><button type="button" class="awfl-ftab">Sitemap</button></a>
        <a href="https://aedtpworld.com/wikiworld/AWFLWIKIWORLD/AWFLWIKIWORLD"><button type="button" class="awfl-ftab">AWFLWIKIWORLD</button></a>


            </div>
            <div class="awfl-footer-copy">© <?= date('Y') ?> AEDTP WORLD — content available under the AEDTP WORLD FREE LICENSE (AWFL)</div>
        </div>
    </footer>
</div><!-- /.awfl-wrapper -->
<script src="<?= htmlspecialchars(awfl_asset_url('assets/site.js')) ?>"></script>
</body>
</html>



















