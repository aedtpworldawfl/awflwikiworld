<?php
/**
 * AWFLWIKIWORLD — Core functions
 * Auth, page storage, wiki markup parsing, routing helpers.
 */

require_once __DIR__ . '/../config.php';

define('AWFL_USERS_FILE', AWFL_ROOT . '/users/users.json');
define('AWFL_NAMESPACES_DIR', AWFL_ROOT . '/namespaces');
define('AWFL_IMAGES_DIR', AWFL_ROOT . '/images');
define('AWFL_SKINS_DIR', AWFL_ROOT . '/skins');

/* =========================================================
   USERS
   ========================================================= */

function awfl_load_users(): array {
    if (!file_exists(AWFL_USERS_FILE)) return [];
    $raw = file_get_contents(AWFL_USERS_FILE);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function awfl_save_users(array $users): bool {
    return file_put_contents(AWFL_USERS_FILE, json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) !== false;
}

function awfl_find_user(string $username): ?array {
    foreach (awfl_load_users() as $u) {
        if (strcasecmp($u['username'], $username) === 0) return $u;
    }
    return null;
}

function awfl_username_taken(string $username): bool {
    return awfl_find_user($username) !== null;
}

function awfl_register_user(string $username, string $password, string $email, string $name, string $secQ, string $secA): array {
    $username = trim($username);
    if ($username === '' || strcasecmp($username, 'admin') === 0) {
        return [false, 'That username is not available.'];
    }
    if (!preg_match('/^[A-Za-z0-9_\-\.]{3,32}$/', $username)) {
        return [false, 'Usernames may only contain letters, numbers, - _ . (3-32 chars).'];
    }
    if (awfl_username_taken($username)) {
        return [false, 'That username is already taken.'];
    }
    if (strlen($password) < 6) {
        return [false, 'Password must be at least 6 characters.'];
    }
    $users = awfl_load_users();
    $users[] = [
        'username'          => $username,
        'password'          => password_hash($password, PASSWORD_DEFAULT),
        'email'             => trim($email),
        'name'              => trim($name) !== '' ? trim($name) : $username,
        'security_question' => $secQ,
        'security_answer'   => password_hash(strtolower(trim($secA)), PASSWORD_DEFAULT),
        'created_at'        => date('c'),
    ];
    awfl_save_users($users);
    return [true, 'Account created. You can now log in.'];
}

function awfl_verify_admin(string $username, string $password): bool {
    global $Username, $Password;
    return hash_equals($Username, $username) && hash_equals($Password, $password);
}

function awfl_login(string $username, string $password): array {
    global $Username;
    if (strcasecmp($username, $Username) === 0) {
        if (awfl_verify_admin($username, $password)) {
            $_SESSION['awfl_user'] = ['username' => $Username, 'name' => $Username, 'is_admin' => true];
            return [true, ''];
        }
        return [false, 'Incorrect admin password.'];
    }
    $u = awfl_find_user($username);
    if (!$u || !password_verify($password, $u['password'])) {
        return [false, 'Incorrect username or password.'];
    }
    $_SESSION['awfl_user'] = ['username' => $u['username'], 'name' => $u['name'], 'is_admin' => false];
    return [true, ''];
}

function awfl_logout(): void {
    unset($_SESSION['awfl_user']);
}

function awfl_current_user(): ?array {
    return $_SESSION['awfl_user'] ?? null;
}

function awfl_is_logged_in(): bool {
    return awfl_current_user() !== null;
}

function awfl_is_admin(): bool {
    $u = awfl_current_user();
    return $u !== null && !empty($u['is_admin']);
}

function awfl_require_login(): void {
    if (!awfl_is_logged_in()) {
        awfl_redirect(awfl_page_url_raw('Special:Login'));
        exit;
    }
}

function awfl_require_admin(): void {
    if (!awfl_is_admin()) {
        http_response_code(403);
        echo "Access denied. Admins only.";
        exit;
    }
}

/* =========================================================
   ROUTING / URLS
   ========================================================= */

/**
 * Title <-> URL/filename form conversion, MediaWiki-style:
 * Display title "Buddy DML" <-> URL/filename form "Buddy_DML".
 * Applied per path segment so "Music Artists/Buddy DML" becomes
 * "Music_Artists/Buddy_DML".
 */
function awfl_title_to_urlform(string $title): string {
    $segments = explode('/', $title);
    $segments = array_map(function ($s) {
        return str_replace(' ', '_', trim($s));
    }, $segments);
    return implode('/', $segments);
}

function awfl_urlform_to_title(string $urlform): string {
    $segments = explode('/', $urlform);
    $segments = array_map(function ($s) {
        return str_replace('_', ' ', trim($s));
    }, $segments);
    return implode('/', $segments);
}

function awfl_redirect(string $url): void {
    header("Location: $url");
}

/** Resolve a config-style path (absolute URL, relative, or full filesystem
 *  path) against $Server so it works from includes rendered by scripts in
 *  any subdirectory (users/, dashboard/, allusers/, sitemap/). */
function awfl_asset_url(string $path): string {
    global $Server;
    if ($path === '') return $path;
    if (preg_match('#^([a-zA-Z][a-zA-Z0-9+.\-]*:)?//#', $path)) return $path; // absolute URL (http://, https://, //cdn...)
    if (preg_match('#^[a-zA-Z]:[\\\\/]#', $path)) return $path; // Windows absolute filesystem path
    if ($path[0] === '/') return $path; // root-relative
    return rtrim($Server, '/') . '/' . ltrim($path, '/');
}

/** Build a URL to a wiki page according to $route in config.php.
 *  Accepts a display-form title ("Buddy DML") and emits the
 *  underscore URL form ("Buddy_DML"), each segment percent-encoded. */
function awfl_page_url_raw(string $title): string {
    global $Server, $route;
    $urlTitle = awfl_title_to_urlform($title);
    $encoded = implode('/', array_map('rawurlencode', explode('/', $urlTitle)));
    if ($route === '1') {
        return rtrim($Server, '/') . '/index.php/' . $encoded;
    } elseif ($route === '2') {
        return rtrim($Server, '/') . '/namespaces/' . $encoded;
    }
    return rtrim($Server, '/') . '/index.php?title=' . $encoded;
}

function awfl_action_url(string $title, string $action): string {
    $base = awfl_page_url_raw($title);
    $sep = (strpos($base, '?') !== false) ? '&' : '?';
    return $base . $sep . 'action=' . rawurlencode($action);
}

/** Determine the requested page title from the current request, honoring $route.
 *  Always returns the display form (spaces, not underscores). */
function awfl_current_title(): string {
    global $route;
    if (!empty($_GET['title'])) {
        return awfl_urlform_to_title(trim($_GET['title'], '/'));
    }
    if ($route === '1' && isset($_SERVER['PATH_INFO'])) {
        return awfl_urlform_to_title(trim($_SERVER['PATH_INFO'], '/'));
    }
    if ($route === '2') {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri = preg_replace('#^.*/namespaces/#', '', $uri);
        return awfl_urlform_to_title(trim(urldecode($uri), '/'));
    }
    return 'Main Page';
}

/* =========================================================
   PAGE STORAGE
   ========================================================= */

function awfl_sanitize_pathpart(string $s): string {
    $s = str_replace(['..', '\\'], '', $s);
    $s = trim($s);
    return $s === '' ? 'Main Page' : $s;
}

/** Split a "Space/Page" title into [space, page]. No slash => [null, page]. */
function awfl_split_title(string $title): array {
    $title = awfl_sanitize_pathpart($title);
    if (strpos($title, '/') !== false) {
        $parts = explode('/', $title, 2);
        return [awfl_sanitize_pathpart($parts[0]), awfl_sanitize_pathpart($parts[1])];
    }
    return [null, $title];
}

function awfl_page_filepath(string $title): string {
    [$space, $page] = awfl_split_title($title);
    $pageFile = awfl_title_to_urlform($page);
    if ($space) {
        $spaceDir = awfl_title_to_urlform($space);
        $dir = AWFL_NAMESPACES_DIR . '/' . $spaceDir;
        return $dir . '/' . $pageFile . '.txt';
    }
    return AWFL_NAMESPACES_DIR . '/' . $pageFile . '.txt';
}

/** Return the namespace portion of a title — everything before the LAST
 *  "/" — or null if the title has no "/" at all. Pure string logic, never
 *  touches the filesystem, so it can safely be checked before deciding
 *  whether to look at (or create) anything on disk. */
function awfl_title_namespace(string $title): ?string {
    $title = trim($title, "/\\ \t\n\r\0\x0B");
    $pos = strrpos($title, '/');
    if ($pos === false) return null;
    return substr($title, 0, $pos);
}

/** Check whether a namespace path ("a" or "a/b/c") already exists as a real
 *  directory under namespaces/. This NEVER creates anything — it only looks.
 *  Namespaces are created exclusively via dashboard/namespaces.php (admin
 *  only); nothing else in the system is allowed to bring one into being. */
function awfl_namespace_exists(string $ns): bool {
    $ns = trim($ns, "/\\ \t\n\r\0\x0B");
    if ($ns === '') return true; // no namespace requested = root, always fine
    $segments = explode('/', $ns);
    $clean = [];
    foreach ($segments as $seg) {
        $seg = trim($seg);
        // Empty segments, ".", "..", or a stray backslash can never be a
        // real namespace folder — treat the whole path as nonexistent.
        if ($seg === '' || $seg === '.' || $seg === '..' || strpos($seg, '\\') !== false) return false;
        $clean[] = str_replace(' ', '_', $seg);
    }
    $dir = AWFL_NAMESPACES_DIR . '/' . implode('/', $clean);
    if (!is_dir($dir)) return false;
    // Defense in depth: confirm the resolved path is still inside namespaces/.
    $real = realpath($dir);
    $realBase = realpath(AWFL_NAMESPACES_DIR);
    if ($real === false || $realBase === false) return false;
    return $real === $realBase || strpos($real . DIRECTORY_SEPARATOR, $realBase . DIRECTORY_SEPARATOR) === 0;
}

function awfl_page_exists(string $title): bool {
    return file_exists(awfl_page_filepath($title));
}

function awfl_load_page(string $title): ?string {
    $path = awfl_page_filepath($title);
    if (!file_exists($path)) return null;
    return file_get_contents($path);
}

function awfl_save_page(string $title, string $content): bool {
    $path = awfl_page_filepath($title);
    $dir = dirname($path);
    // Never auto-create a namespace folder here. The directory must already
    // exist — either it's the namespaces/ root (always present) or an admin
    // created it via dashboard/namespaces.php. If it's missing, refuse to
    // write rather than silently bringing a new namespace into existence.
    if (!is_dir($dir)) return false;
    return file_put_contents($path, $content) !== false;
}

function awfl_delete_page(string $title): bool {
    $path = awfl_page_filepath($title);
    return file_exists($path) ? unlink($path) : false;
}

/** List all wiki pages as an array of title strings (Space/Page or Page) */
function awfl_list_pages(): array {
    $pages = [];
    if (!is_dir(AWFL_NAMESPACES_DIR)) return $pages;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(AWFL_NAMESPACES_DIR, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $file) {
        if ($file->getExtension() !== 'txt') continue;
        $rel = str_replace(AWFL_NAMESPACES_DIR . '/', '', $file->getPathname());
        $title = preg_replace('/\.txt$/', '', $rel);
        $pages[] = awfl_urlform_to_title($title);
    }
    sort($pages);
    return $pages;
}

/* =========================================================
   WIKI MARKUP PARSER
   ========================================================= */

const AWFL_IMAGE_EXT = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'];

function awfl_is_image_src(string $s): bool {
    $ext = strtolower(pathinfo(parse_url($s, PHP_URL_PATH) ?? $s, PATHINFO_EXTENSION));
    return in_array($ext, AWFL_IMAGE_EXT, true);
}

function awfl_resolve_image_url(string $src): string {
    // absolute (http/https) or already relative/full path — pass through.
    if (preg_match('#^(https?:)?//#i', $src) || preg_match('#^[a-zA-Z]:[\\\\/]#', $src) || $src[0] === '/') {
        return $src;
    }
    if (str_starts_with($src, 'images/')) return $src;
    // bare filename => assume uploaded image
    return 'images/' . ltrim($src, '/');
}

/** Parse a single <infobox>...</infobox> inner block into an HTML table. */
function awfl_render_infobox(string $inner): string {
    $lines = preg_split('/\r\n|\r|\n/', trim($inner));
    $title = null; $image = null; $caption = null;
    $rows = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;
        // format: |key=value|  (trailing pipe optional)
        if (!preg_match('/^\|\s*([^=|]+?)\s*=\s*(.*?)\s*\|?$/', $line, $m)) continue;
        $key = trim($m[1]);
        $val = trim($m[2]);
        $keyLower = strtolower($key);
        if ($keyLower === 'title' && $title === null) { $title = $val; continue; }
        if ($keyLower === 'image' && $image === null) { $image = $val; continue; }
        if ($keyLower === 'caption' && $caption === null) { $caption = $val; continue; }
        $rows[] = [$key, $val];
    }

    $html = '<table class="infobox">';
    if ($title !== null) {
        $html .= '<tr><th class="infobox-title" colspan="2">' . htmlspecialchars($title) . '</th></tr>';
    }
    if ($image !== null) {
        $imgUrl = awfl_resolve_image_url($image);
        $alt = $caption !== null ? htmlspecialchars($caption) : htmlspecialchars($title ?? '');
        $html .= '<tr><td colspan="2" class="infobox-image">';
        $html .= '<img src="' . htmlspecialchars($imgUrl) . '" alt="' . $alt . '" style="width:250px !important;height:auto;">';
        if ($caption !== null) {
            $html .= '<div class="infobox-caption">' . htmlspecialchars($caption) . '</div>';
        }
        $html .= '</td></tr>';
    }
    foreach ($rows as [$k, $v]) {
        $vHtml = awfl_is_image_src($v)
            ? '<img src="' . htmlspecialchars(awfl_resolve_image_url($v)) . '" style="width:250px !important;height:auto;">'
            : nl2br(htmlspecialchars($v));
        $html .= '<tr><th>' . htmlspecialchars($k) . '</th><td>' . $vHtml . '</td></tr>';
    }
    $html .= '</table>';
    return $html;
}

/** Convert AWFL wiki markup to safe HTML. */
function awfl_parse_wiki(string $text): string {
    // Normalize line endings first. Browsers submit textarea content with
    // CRLF, and a stray "\r" left before every "\n" silently breaks any rule
    // anchored with a strict end-of-line "$" (e.g. headings, which use
    // "[ \t]*$" rather than "\s*$" on purpose — see note below) since PCRE's
    // "$" does not treat "\r" as part of the line ending on its own.
    $text = str_replace(["\r\n", "\r"], "\n", $text);

    // 0. Pull out <nowiki>...</nowiki> spans first so nothing inside them
    // is ever treated as markup — used to show raw AWFLWIKITEXT syntax
    // literally (e.g. in documentation pages).
    $nowikis = [];
    $text = preg_replace_callback('/<nowiki>(.*?)<\/nowiki>/is', function ($m) use (&$nowikis) {
        $key = "\x02NOWIKI" . count($nowikis) . "\x02";
        $nowikis[$key] = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
        return $key;
    }, $text);

    // 1. Pull out infobox blocks so the rest of the pipeline doesn't touch them.
    $infoboxes = [];
    $text = preg_replace_callback('/<infobox>(.*?)<\/infobox>/is', function ($m) use (&$infoboxes) {
        $key = "\x01INFOBOX" . count($infoboxes) . "\x01";
        $infoboxes[$key] = awfl_render_infobox($m[1]);
        return $key;
    }, $text);

    // 1b. Pull out {{{ code blocks }}} the same way — preformatted, monospace,
    // and never touched by any other markup rule.
    $codeblocks = [];
    $text = preg_replace_callback('/\{\{\{(.*?)\}\}\}/s', function ($m) use (&$codeblocks) {
        $key = "\x03CODEBLOCK" . count($codeblocks) . "\x03";
        $codeblocks[$key] = '<pre><code>' . htmlspecialchars(trim($m[1], "\n"), ENT_QUOTES, 'UTF-8') . '</code></pre>';
        return $key;
    }, $text);

    // 2. Escape everything else, then re-apply markup on the escaped text.
    $text = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    // Headings: = Heading =  (1-6 =, matching heading levels 1-6)
    // NOTE: use [ \t]* (not \s*) around the markers so this never eats the
    // newline(s) that follow — \s* would swallow a blank line here and
    // silently merge the heading with the next paragraph.
    $text = preg_replace_callback('/^(={1,6})[ \t]*(.+?)[ \t]*\1[ \t]*$/m', function ($m) {
        $level = strlen($m[1]);
        return "<h{$level}>" . trim($m[2]) . "</h{$level}>";
    }, $text);

    // Bold '''text'''
    $text = preg_replace('/&#039;&#039;&#039;(.+?)&#039;&#039;&#039;/s', '<strong>$1</strong>', $text);
    // Italic ''text''
    $text = preg_replace('/&#039;&#039;(.+?)&#039;&#039;/s', '<em>$1</em>', $text);
    // Underline __text__
    $text = preg_replace('/__(.+?)__/s', '<u>$1</u>', $text);
    // Strikethrough ~~text~~
    $text = preg_replace('/~~(.+?)~~/s', '<del>$1</del>', $text);
    // Inline code `text`
    $text = preg_replace('/`([^`\n]+?)`/s', '<code>$1</code>', $text);
    // Superscript ^^text^^
    $text = preg_replace('/\^\^(.+?)\^\^/s', '<sup>$1</sup>', $text);
    // Subscript ,,text,,
    $text = preg_replace('/,,(.+?),,/s', '<sub>$1</sub>', $text);
    // Highlight %%text%%
    $text = preg_replace('/%%(.+?)%%/s', '<mark>$1</mark>', $text);

    // Internal links [[Page]] or [[Page|Text]]
    $text = preg_replace_callback('/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/', function ($m) {
        $target = trim($m[1]);
        $label = isset($m[2]) ? trim($m[2]) : $target;
        $url = awfl_page_url_raw($target);
        $exists = awfl_page_exists($target);
        $cls = $exists ? 'wiki-link' : 'wiki-link new';
        return '<a class="' . $cls . '" href="' . htmlspecialchars($url) . '">' . $label . '</a>';
    }, $text);

    // External links [http://url Text]
    $text = preg_replace_callback('/\[(https?:\/\/[^\s\]]+)\s+([^\]]+)\]/', function ($m) {
        return '<a href="' . $m[1] . '" target="_blank" rel="noopener noreferrer">' . $m[2] . '</a>';
    }, $text);

    // Bare image lines/tokens (filename or URL ending in an image extension)
    $text = preg_replace_callback('/(?<![="\'])(\bhttps?:\/\/[^\s<]+\.(?:jpg|jpeg|png|gif|svg|webp)\b|\b[\w\-\/\.]+\.(?:jpg|jpeg|png|gif|svg|webp)\b)/i', function ($m) {
        $src = html_entity_decode($m[1]);
        $url = awfl_resolve_image_url($src);
        return '<img src="' . htmlspecialchars($url) . '" style="width:250px !important;height:auto;" alt="">';
    }, $text);

    // Lists: consecutive lines starting with * (unordered) or # (ordered).
    // Also handles blockquote lines (> text) and horizontal rules (----).
    $lines = explode("\n", $text);
    $out = [];
    $listType = null;
    $inBlockquote = false;
    foreach ($lines as $line) {
        // Horizontal rule: a line of 4+ dashes on its own.
        if (preg_match('/^-{4,}\s*$/', $line)) {
            if ($listType) { $out[] = "</{$listType}>"; $listType = null; }
            if ($inBlockquote) { $out[] = '</blockquote>'; $inBlockquote = false; }
            $out[] = '<hr>';
            continue;
        }
        // Blockquote: lines starting with "> " (already HTML-escaped to "&gt; ").
        if (preg_match('/^&gt;\s?(.*)$/', $line, $m)) {
            if ($listType) { $out[] = "</{$listType}>"; $listType = null; }
            if (!$inBlockquote) { $out[] = '<blockquote>'; $inBlockquote = true; }
            $out[] = $m[1];
            continue;
        }
        if ($inBlockquote) { $out[] = '</blockquote>'; $inBlockquote = false; }

        if (preg_match('/^\*\s?(.*)$/', $line, $m)) {
            if ($listType !== 'ul') { if ($listType) $out[] = "</{$listType}>"; $out[] = '<ul>'; $listType = 'ul'; }
            $out[] = '<li>' . $m[1] . '</li>';
        } elseif (preg_match('/^#\s?(.*)$/', $line, $m)) {
            if ($listType !== 'ol') { if ($listType) $out[] = "</{$listType}>"; $out[] = '<ol>'; $listType = 'ol'; }
            $out[] = '<li>' . $m[1] . '</li>';
        } else {
            if ($listType) { $out[] = "</{$listType}>"; $listType = null; }
            $out[] = $line;
        }
    }
    if ($listType) $out[] = "</{$listType}>";
    if ($inBlockquote) $out[] = '</blockquote>';
    $text = implode("\n", $out);

    // Paragraphs: blank-line separated blocks that aren't already block-level HTML
    $blocks = preg_split('/\n{2,}/', trim($text));
    $blocks = array_map(function ($b) {
        $b = trim($b);
        if ($b === '') return '';
        if (preg_match('/^\x01INFOBOX\d+\x01$/', $b)) return $b; // don't wrap infobox placeholders in <p>
        if (preg_match('/^\x03CODEBLOCK\d+\x03$/', $b)) return $b; // don't wrap code block placeholders in <p>
        if (preg_match('/^\s*<(h[1-6]|ul|ol|table|div|p|hr|blockquote|pre)\b/i', $b)) return $b;
        return '<p>' . nl2br($b) . '</p>';
    }, $blocks);
    $text = implode("\n", $blocks);

    // 3. Restore infobox HTML.
    foreach ($infoboxes as $key => $html) {
        $text = str_replace($key, $html, $text);
    }

    // 3b. Restore {{{ code block }}} HTML.
    foreach ($codeblocks as $key => $html) {
        $text = str_replace($key, $html, $text);
    }

    // 4. Restore <nowiki> spans as literal, already-escaped text — wrapped in
    // a detectable marker span so the Visual editor's HTML->wikitext
    // converter can round-trip it back into <nowiki>...</nowiki> instead of
    // losing the escape (which would otherwise let the un-escaped markup
    // get interpreted for real the next time the page is saved).
    foreach ($nowikis as $key => $escaped) {
        $text = str_replace($key, '<span class="awfl-nowiki">' . $escaped . '</span>', $text);
    }

    return $text;
}

/* =========================================================
   PAGE PROTECTION
   ========================================================= */

define('AWFL_PROTECTED_FILE', AWFL_ROOT . '/dashboard/protected.json');

function awfl_load_protected(): array {
    if (!file_exists(AWFL_PROTECTED_FILE)) return [];
    $d = json_decode(file_get_contents(AWFL_PROTECTED_FILE), true);
    return is_array($d) ? $d : [];
}

function awfl_save_protected(array $list): void {
    if (!is_dir(dirname(AWFL_PROTECTED_FILE))) @mkdir(dirname(AWFL_PROTECTED_FILE), 0775, true);
    file_put_contents(AWFL_PROTECTED_FILE, json_encode(array_values(array_unique($list)), JSON_PRETTY_PRINT));
}

/** Protection is tracked by the title's underscore/URL form so it's stable
 *  regardless of how the title was capitalized/spaced when checked. */
function awfl_is_protected(string $title): bool {
    return in_array(awfl_title_to_urlform($title), awfl_load_protected(), true);
}

function awfl_set_protected(string $title, bool $protected): void {
    $key = awfl_title_to_urlform($title);
    $list = awfl_load_protected();
    if ($protected) {
        if (!in_array($key, $list, true)) $list[] = $key;
    } else {
        $list = array_values(array_filter($list, fn($t) => $t !== $key));
    }
    awfl_save_protected($list);
}

/* =========================================================
   ADMIN EDIT HISTORY (latest admin edit per page only)
   ========================================================= */

define('AWFL_HISTORY_FILE', AWFL_ROOT . '/dashboard/history.json');

function awfl_load_history(): array {
    if (!file_exists(AWFL_HISTORY_FILE)) return [];
    $d = json_decode(file_get_contents(AWFL_HISTORY_FILE), true);
    return is_array($d) ? $d : [];
}

function awfl_save_history(array $entries): void {
    if (!is_dir(dirname(AWFL_HISTORY_FILE))) @mkdir(dirname(AWFL_HISTORY_FILE), 0775, true);
    file_put_contents(AWFL_HISTORY_FILE, json_encode(array_values($entries), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
}

/** Record (or overwrite) the latest admin edit for a page. No duplicates —
 *  matched by namespace + filename, the record is updated in place. */
function awfl_record_history(string $title, string $content): void {
    [$space, $page] = awfl_split_title($title);
    $filename = awfl_title_to_urlform($page) . '.txt';
    $namespace = $space ? awfl_title_to_urlform($space) : '';
    $entries = awfl_load_history();
    $found = false;
    foreach ($entries as &$e) {
        if (($e['filename'] ?? '') === $filename && ($e['namespace'] ?? '') === $namespace) {
            $e['pagename'] = $title;
            $e['date'] = date('c');
            $e['content'] = $content;
            $found = true;
            break;
        }
    }
    unset($e);
    if (!$found) {
        $entries[] = [
            'pagename'  => $title,
            'filename'  => $filename,
            'namespace' => $namespace,
            'date'      => date('c'),
            'content'   => $content,
        ];
    }
    awfl_save_history($entries);
}

/* =========================================================
   IMAGE UPLOAD
   ========================================================= */

define('AWFL_IMAGES_TRASH_DIR', AWFL_IMAGES_DIR . '/trash');

function awfl_ensure_images_trash_dir(): void {
    if (!is_dir(AWFL_IMAGES_TRASH_DIR)) @mkdir(AWFL_IMAGES_TRASH_DIR, 0775, true);
}

function awfl_human_filesize(int $bytes): string {
    if ($bytes < 1024) return $bytes . ' B';
    $units = ['KB', 'MB', 'GB'];
    $val = $bytes;
    foreach ($units as $u) {
        $val /= 1024;
        if ($val < 1024) return round($val, 1) . ' ' . $u;
    }
    return round($val, 1) . ' TB';
}

/** List image files in the given bucket ('active' = images/, 'trash' = images/trash/). */
function awfl_list_image_files(string $bucket = 'active'): array {
    $dir = $bucket === 'trash' ? AWFL_IMAGES_TRASH_DIR : AWFL_IMAGES_DIR;
    if (!is_dir($dir)) return [];
    $out = [];
    foreach (scandir($dir) as $f) {
        if ($f === '.' || $f === '..' || is_dir($dir . '/' . $f)) continue;
        $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png'], true)) continue;
        $path = $dir . '/' . $f;
        $out[] = [
            'name' => $f,
            'ext'  => $ext,
            'size' => filesize($path),
            'mtime' => filemtime($path),
        ];
    }
    return $out;
}

function awfl_sort_images(array $images, string $sortBy, string $dir = 'asc'): array {
    $sortBy = in_array($sortBy, ['name', 'ext', 'size', 'mtime'], true) ? $sortBy : 'name';
    usort($images, function ($a, $b) use ($sortBy) {
        return $a[$sortBy] <=> $b[$sortBy];
    });
    if ($dir === 'desc') $images = array_reverse($images);
    return $images;
}

function awfl_move_image_to_trash(string $filename): bool {
    awfl_ensure_images_trash_dir();
    $filename = basename($filename);
    $src = AWFL_IMAGES_DIR . '/' . $filename;
    if (!file_exists($src)) return false;
    $dest = AWFL_IMAGES_TRASH_DIR . '/' . $filename;
    $i = 1;
    while (file_exists($dest)) {
        $dest = AWFL_IMAGES_TRASH_DIR . '/' . pathinfo($filename, PATHINFO_FILENAME) . "-$i." . pathinfo($filename, PATHINFO_EXTENSION);
        $i++;
    }
    return rename($src, $dest);
}

function awfl_restore_image_from_trash(string $filename): bool {
    $filename = basename($filename);
    $src = AWFL_IMAGES_TRASH_DIR . '/' . $filename;
    if (!file_exists($src)) return false;
    $dest = AWFL_IMAGES_DIR . '/' . $filename;
    $i = 1;
    while (file_exists($dest)) {
        $dest = AWFL_IMAGES_DIR . '/' . pathinfo($filename, PATHINFO_FILENAME) . "-$i." . pathinfo($filename, PATHINFO_EXTENSION);
        $i++;
    }
    return rename($src, $dest);
}

function awfl_rename_image(string $oldName, string $newName, string $bucket = 'active'): array {
    $dir = $bucket === 'trash' ? AWFL_IMAGES_TRASH_DIR : AWFL_IMAGES_DIR;
    $oldName = basename($oldName);
    $ext = pathinfo($oldName, PATHINFO_EXTENSION);
    $newBase = preg_replace('/[^A-Za-z0-9_\-]/', '_', pathinfo($newName, PATHINFO_FILENAME));
    if ($newBase === '') return [false, 'Invalid new name.'];
    $newFull = $newBase . '.' . $ext;
    $src = $dir . '/' . $oldName;
    $dest = $dir . '/' . $newFull;
    if (!file_exists($src)) return [false, "$oldName not found."];
    if (file_exists($dest)) return [false, "$newFull already exists."];
    return rename($src, $dest) ? [true, $newFull] : [false, 'Rename failed.'];
}

function awfl_handle_image_upload(array $file): array {
    global $ImageUpload;
    if (!$ImageUpload) return [false, 'Image uploads are disabled.'];
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) return [false, 'Upload failed.'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png'], true)) return [false, 'Only .jpg and .png files are accepted.'];
    $safeName = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
    $target = AWFL_IMAGES_DIR . '/' . $safeName . '.' . $ext;
    $i = 1;
    while (file_exists($target)) {
        $target = AWFL_IMAGES_DIR . '/' . $safeName . '-' . $i . '.' . $ext;
        $i++;
    }
    if (!move_uploaded_file($file['tmp_name'], $target)) return [false, 'Could not save file.'];
    return [true, basename($target)];
}

/* =========================================================
   ADMIN COLOR PALETTE
   ========================================================= */

/** Maps a dashboard color field key => [CSS custom property, human label]. */
function awfl_color_fields(): array {
    return [
        'header_bg'    => ['--awfl-header-bg', 'Header'],
        'header_text'  => ['--awfl-header-text', 'Header Text'],
        'button_bg'    => ['--awfl-button-bg', 'Button'],
        'button_text'  => ['--awfl-button-text', 'Button Text'],
        'page_text'    => ['--awfl-page-text', 'Wiki page text'],
        'link'         => ['--awfl-link', 'Links'],
    ];
}

/** Build a single CSS blob (default site.css + active skin + admin color
 *  overrides) so a downloaded standalone HTML file looks like the live
 *  page even when opened with no connection back to the wiki. */
function awfl_build_download_css(): string {
    global $Skin, $AwflColors;
    $css = '';

    $siteCssPath = AWFL_ROOT . '/assets/site.css';
    if (file_exists($siteCssPath)) $css .= file_get_contents($siteCssPath) . "\n";

    // Only inline the skin if it's a local file under the wiki root;
    // an admin-set external skin URL is linked instead (see caller).
    if (!preg_match('#^https?://#i', $Skin)) {
        $localSkinPath = AWFL_ROOT . '/' . ltrim($Skin, '/');
        if (file_exists($localSkinPath)) $css .= file_get_contents($localSkinPath) . "\n";
    }

    if (!empty($AwflColors)) {
        $css .= ":root {\n";
        foreach (awfl_color_fields() as $key => [$cssVar, $label]) {
            if (!empty($AwflColors[$key])) $css .= "  $cssVar: " . $AwflColors[$key] . ";\n";
        }
        $css .= "}\n";
    }
    return $css;
}

/* =========================================================
   SKINS
   ========================================================= */

function awfl_list_skins(): array {
    $skins = [];
    foreach (glob(AWFL_SKINS_DIR . '/*.css') as $f) {
        $skins[] = basename($f, '.css');
    }
    return $skins;
}

/* =========================================================
   EXPORT FORMATS (download action)
   ========================================================= */

/** List of formats offered by the "Download" links, in display order. */
function awfl_download_formats(): array {
    return [
        'txt'  => ['label' => '.txt',  'ext' => 'txt'],
        'md'   => ['label' => '.md',   'ext' => 'md'],
        'html' => ['label' => '.html', 'ext' => 'html'],
        'json' => ['label' => '.json', 'ext' => 'json'],
        'pdf'  => ['label' => '.pdf',  'ext' => 'pdf'],
        'xml'  => ['label' => '.xml',  'ext' => 'xml'],
    ];
}

/** Convert AWFLWIKITEXT markup into (reasonably) equivalent Markdown. */
function awfl_wiki_to_markdown(string $text): string {
    // Normalize line endings up front — see the matching note in
    // awfl_parse_wiki() for why a stray "\r" before "\n" matters here too.
    $text = str_replace(["\r\n", "\r"], "\n", $text);

    // Pull out infobox blocks and render them as a small markdown table.
    $text = preg_replace_callback('/<infobox>(.*?)<\/infobox>/is', function ($m) {
        $lines = preg_split('/\r\n|\r|\n/', trim($m[1]));
        $rows = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            if (!preg_match('/^\|\s*([^=|]+?)\s*=\s*(.*?)\s*\|?$/', $line, $mm)) continue;
            $rows[] = [trim($mm[1]), trim($mm[2])];
        }
        if (!$rows) return '';
        $out = "| Field | Value |\n| --- | --- |\n";
        foreach ($rows as [$k, $v]) {
            $v = str_replace(["\r\n", "\n", "|"], [' ', ' ', '\\|'], $v);
            $out .= "| $k | $v |\n";
        }
        return "\n" . $out . "\n";
    }, $text);

    // Strip <nowiki> tags but keep their literal contents.
    $text = preg_replace_callback('/<nowiki>(.*?)<\/nowiki>/is', fn($m) => $m[1], $text);

    // Code blocks {{{ ... }}} -> fenced Markdown code blocks.
    $text = preg_replace_callback('/\{\{\{(.*?)\}\}\}/s', function ($m) {
        return "\n```\n" . trim($m[1], "\n") . "\n```\n";
    }, $text);

    // Lists: '*' (unordered) stays valid Markdown as-is. Convert AWFLWIKITEXT's
    // ordered-list marker '#' into Markdown numbering BEFORE headings are
    // turned into '#' below — otherwise a level-1 heading ('# Heading') would
    // be indistinguishable from a genuine single-'#' list item.
    $lines = explode("\n", $text);
    $out = [];
    $olCounter = 0;
    foreach ($lines as $line) {
        if (preg_match('/^#\s?(.*)$/', $line, $m)) {
            $olCounter++;
            $out[] = $olCounter . '. ' . $m[1];
        } else {
            $olCounter = 0; // any non-list line resets numbering for the next list
            $out[] = $line;
        }
    }
    $text = implode("\n", $out);

    // Headings: = Heading = (N '=' signs, N = 1-6) -> N '#' signs.
    $text = preg_replace_callback('/^(={1,6})[ \t]*(.+?)[ \t]*\1[ \t]*$/m', function ($m) {
        return str_repeat('#', strlen($m[1])) . ' ' . trim($m[2]);
    }, $text);

    // Bold / italic / underline / strikethrough / code / superscript / subscript / highlight.
    $text = preg_replace('/\'\'\'(.+?)\'\'\'/s', '**$1**', $text);
    $text = preg_replace('/\'\'(.+?)\'\'/s', '*$1*', $text);
    $text = preg_replace('/__(.+?)__/s', '<u>$1</u>', $text);
    $text = preg_replace('/~~(.+?)~~/s', '~~$1~~', $text);
    $text = preg_replace('/`([^`\n]+?)`/s', '`$1`', $text);
    $text = preg_replace('/\^\^(.+?)\^\^/s', '<sup>$1</sup>', $text);
    $text = preg_replace('/,,(.+?),,/s', '<sub>$1</sub>', $text);
    $text = preg_replace('/%%(.+?)%%/s', '==$1==', $text);

    // Blockquote lines "> text" and horizontal rules "----" are already
    // valid Markdown as-is, so no conversion needed for those.

    // Internal links [[Page]] or [[Page|Text]].
    $text = preg_replace_callback('/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/', function ($m) {
        $target = trim($m[1]);
        $label = isset($m[2]) ? trim($m[2]) : $target;
        return '[' . $label . '](' . awfl_page_url_raw($target) . ')';
    }, $text);

    // External links [http://url Text].
    $text = preg_replace_callback('/\[(https?:\/\/[^\s\]]+)\s+([^\]]+)\]/', function ($m) {
        return '[' . $m[2] . '](' . $m[1] . ')';
    }, $text);

    // Bare image references -> markdown image syntax.
    $text = preg_replace_callback('/(?<![("\'])(\bhttps?:\/\/[^\s<]+\.(?:jpg|jpeg|png|gif|svg|webp)\b|\b[\w\-\/\.]+\.(?:jpg|jpeg|png|gif|svg|webp)\b)/i', function ($m) {
        return '![](' . awfl_resolve_image_url($m[1]) . ')';
    }, $text);

    return trim($text) . "\n";
}

/** Turn rendered AWFL HTML into readable plain text (used for PDF/plaintext export). */
function awfl_html_to_plaintext(string $html): string {
    $text = preg_replace('/<br\s*\/?>/i', "\n", $html);
    $text = preg_replace('/<\/(h[1-6])>/i', "\n\n", $text);
    $text = preg_replace('/<(h[1-6])[^>]*>/i', "\n", $text);
    $text = preg_replace('/<li[^>]*>/i', "\n- ", $text);
    $text = preg_replace('/<\/(p|div|tr|table|li)>/i', "\n", $text);
    $text = preg_replace('/<th[^>]*>/i', '', $text);
    $text = preg_replace('/<\/th>/i', ': ', $text);
    $text = preg_replace('/<td[^>]*>/i', '', $text);
    $text = preg_replace('/<\/td>/i', '  ', $text);
    $text = strip_tags($text);
    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    $text = preg_replace('/[ \t]+\n/', "\n", $text);
    $text = preg_replace('/\n{3,}/', "\n\n", $text);
    return trim($text);
}

/** Escape a string for use inside a PDF literal string "(...)" and
 *  transliterate it down to Latin-1 since we only embed the base-14
 *  Helvetica font (no embedded font program / unicode support). */
function awfl_pdf_escape(string $s): string {
    $converted = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $s);
    if ($converted === false) $converted = preg_replace('/[^\x20-\x7E]/', '?', $s);
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $converted);
}

/** Assemble a minimal but valid PDF file from a map of object-number => body. */
function awfl_assemble_pdf(array $objects): string {
    ksort($objects);
    $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
    $offsets = [];
    foreach ($objects as $num => $body) {
        $offsets[$num] = strlen($pdf);
        $pdf .= "$num 0 obj\n$body\nendobj\n";
    }
    $maxObj = max(array_keys($objects));
    $xrefStart = strlen($pdf);
    $pdf .= "xref\n0 " . ($maxObj + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i <= $maxObj; $i++) {
        $pdf .= isset($offsets[$i])
            ? sprintf("%010d 00000 n \n", $offsets[$i])
            : "0000000000 00000 f \n";
    }
    $pdf .= "trailer\n<< /Size " . ($maxObj + 1) . " /Root 1 0 R >>\n";
    $pdf .= "startxref\n$xrefStart\n%%EOF";
    return $pdf;
}

/** Generate a simple, dependency-free one-or-more-page PDF for a wiki page. */
function awfl_generate_simple_pdf(string $title, string $bodyText): string {
    $pageWidth = 612; $pageHeight = 792; $margin = 50;
    $fontSize = 11; $lineHeight = 15;
    $charsPerLine = 92;

    $paragraphs = preg_split('/\n{2,}/', trim($bodyText));
    $lines = [];
    foreach ($paragraphs as $para) {
        $para = trim($para);
        if ($para === '') continue;
        foreach (explode("\n", wordwrap($para, $charsPerLine, "\n", true)) as $ln) {
            $lines[] = $ln;
        }
        $lines[] = '';
    }

    $titleLines = explode("\n", wordwrap($title, 46, "\n", true));
    $linesPerPage = (int) floor(($pageHeight - $margin * 2) / $lineHeight);
    $firstPageCapacity = max(1, $linesPerPage - count($titleLines) * 2 - 2);

    $pages = [];
    $remaining = $lines;
    $pages[] = ['title' => $titleLines, 'lines' => array_splice($remaining, 0, $firstPageCapacity)];
    while (!empty($remaining)) {
        $pages[] = ['title' => null, 'lines' => array_splice($remaining, 0, $linesPerPage)];
    }

    $numPages = count($pages);
    $pageObjStart = 5; // 1=Catalog, 2=Pages, 3=Font regular, 4=Font bold
    $contentObjStart = $pageObjStart + $numPages;

    $objects = [];
    $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
    $kids = [];
    for ($i = 0; $i < $numPages; $i++) $kids[] = ($pageObjStart + $i) . ' 0 R';
    $objects[2] = "<< /Type /Pages /Kids [" . implode(' ', $kids) . "] /Count $numPages "
        . "/MediaBox [0 0 $pageWidth $pageHeight] >>";
    $objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
    $objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";

    foreach ($pages as $i => $page) {
        $pageObjNum = $pageObjStart + $i;
        $contentObjNum = $contentObjStart + $i;

        $y = $pageHeight - $margin;
        $stream = "BT\n";
        if ($page['title']) {
            $stream .= "/F2 18 Tf\n";
            foreach ($page['title'] as $tline) {
                $stream .= "1 0 0 1 $margin $y Tm (" . awfl_pdf_escape($tline) . ") Tj\n";
                $y -= 24;
            }
            $y -= 8;
        }
        $stream .= "/F1 $fontSize Tf\n";
        foreach ($page['lines'] as $line) {
            if ($line !== '') {
                $stream .= "1 0 0 1 $margin $y Tm (" . awfl_pdf_escape($line) . ") Tj\n";
            }
            $y -= $lineHeight;
        }
        $stream .= "ET";

        $objects[$pageObjNum] = "<< /Type /Page /Parent 2 0 R "
            . "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> "
            . "/Contents $contentObjNum 0 R >>";
        $objects[$contentObjNum] = "<< /Length " . strlen($stream) . " >>\nstream\n$stream\nendstream";
    }

    return awfl_assemble_pdf($objects);
}

/** Build a small XML export of a wiki page (title, metadata, wikitext, rendered html). */
function awfl_generate_page_xml(string $title, ?string $space, string $raw, string $renderedHtml): string {
    $xml = new SimpleXMLElement('<page/>');
    $xml->addChild('title', htmlspecialchars($title, ENT_XML1, 'UTF-8'));
    if ($space) $xml->addChild('space', htmlspecialchars($space, ENT_XML1, 'UTF-8'));
    $xml->addChild('exported', date('c'));
    $wikitextNode = $xml->addChild('wikitext');
    $wikitextDom = dom_import_simplexml($wikitextNode);
    $wikitextDom->appendChild($wikitextDom->ownerDocument->createCDATASection($raw));
    $htmlNode = $xml->addChild('html');
    $htmlDom = dom_import_simplexml($htmlNode);
    $htmlDom->appendChild($htmlDom->ownerDocument->createCDATASection($renderedHtml));

    $dom = dom_import_simplexml($xml)->ownerDocument;
    $dom->formatOutput = true;
    return $dom->saveXML();
}



















