<?php
/**
 * includes/header.php
 * Expects (optionally) to be included after the following are set:
 *   $pagename         — the page/article title being shown
 *   $pageDescription  — description for this specific page (namespace pages)
 *   $space            — namespace/space name, if any
 *   $headerMode       — 'interface' (default site chrome) or 'page' (article page)
 *   $canonicalUrl     — full canonical URL of the current view
 */
$pagename        = $pagename ?? $Sitename;
$pageDescription = $pageDescription ?? $MetaDescription;
$space            = $space ?? null;
$headerMode       = $headerMode ?? 'interface';
$canonicalUrl     = $canonicalUrl ?? $Server;
$currentUser      = awfl_current_user();
$logoUrl          = awfl_asset_url($Logo);
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php if ($headerMode === 'interface'): ?>
    <title><?= htmlspecialchars($pagename) ?> — <?= htmlspecialchars($MetaTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($MetaDescription) ?>">
    <meta name="author" content="AEDTP WORLD">
    <meta name="copyright" content="© AEDTP WORLD">
    <meta name="keywords" content="AEDTP WORLD, AEDTP WORLD FREE LICENSE, AWFL, AWFLWIKIWORLD, WIKI, Discover And Connect">
    <meta name="license" content="AEDTP WORLD FREE LICENSE (AWFL)">
    <meta name="robots" content="index, follow">
    <meta name="application-name" content="<?= htmlspecialchars($MetaTitle) ?>">
    <link rel="canonical" href="<?= htmlspecialchars($canonicalUrl) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($pagename) ?> — <?= htmlspecialchars($MetaTitle) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($MetaDescription) ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= htmlspecialchars($Server) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($logoUrl) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars($MetaTitle) ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($pagename) ?> — <?= htmlspecialchars($MetaTitle) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($MetaDescription) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($logoUrl) ?>">
    <link rel="icon" href="<?= htmlspecialchars($logoUrl) ?>">
    <link rel="apple-touch-icon" href="<?= htmlspecialchars($logoUrl) ?>">
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "<?= htmlspecialchars($MetaTitle) ?>",
      "logo": "<?= htmlspecialchars($logoUrl) ?>",
      "alternateName": "AEDTP WORLD FREE LICENSE (AWFL)",
      "url": "<?= htmlspecialchars($Server) ?>",
      "description": "<?= htmlspecialchars($MetaDescription) ?>",
      "publisher": { "@type": "Organization", "name": "<?= htmlspecialchars($MetaTitle) ?>" },
      "sameAs": [
        "https://aedtpworld.com",
        "https://youtube.com/@aedtpworld",
        "https://www.crunchbase.com/organization/aedtpworld",
        "https://soundbetter.com/profiles/636065-aedtp-world",
        "https://www.f6s.com/aedtpworld"
      ]
    }
    </script>
<?php else: $titleSuffix = $space ? (htmlspecialchars($space) . ' — ' . htmlspecialchars($MetaTitle)) : htmlspecialchars($MetaTitle); ?>
    <title><?= htmlspecialchars($pagename) ?> — <?= $titleSuffix ?></title>
    <meta name="description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta name="author" content="AEDTP WORLD">
    <meta name="copyright" content="© AEDTP WORLD">
    <meta name="keywords" content="AEDTP WORLD, AEDTP WORLD FREE LICENSE, AWFL, AWFLWIKIWORLD, WIKI, Discover And Connect">
    <meta name="license" content="AEDTP WORLD FREE LICENSE (AWFL)">
    <meta name="robots" content="index, follow">
    <meta name="application-name" content="<?= htmlspecialchars($MetaTitle) ?>">
    <link rel="canonical" href="<?= htmlspecialchars($canonicalUrl) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($pagename) ?> — <?= $titleSuffix ?>">
    <meta property="og:description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= htmlspecialchars($Server) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($logoUrl) ?>">
    <meta property="og:site_name" content="<?= htmlspecialchars($MetaTitle) ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= htmlspecialchars($pagename) ?> — <?= $titleSuffix ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($logoUrl) ?>">
    <link rel="icon" href="<?= htmlspecialchars($logoUrl) ?>">
    <link rel="apple-touch-icon" href="<?= htmlspecialchars($logoUrl) ?>">
<?php endif; ?>
    <link rel="stylesheet" href="<?= htmlspecialchars(awfl_asset_url('assets/site.css')) ?>">
    <link rel="stylesheet" href="<?= htmlspecialchars(awfl_asset_url($Skin)) ?>" id="awfl-skin">
<?php if (!empty($AwflColors)): ?>
    <style id="awfl-color-overrides">
        :root {
<?php foreach (awfl_color_fields() as $key => [$cssVar, $label]): if (!empty($AwflColors[$key])): ?>
            <?= $cssVar ?>: <?= htmlspecialchars($AwflColors[$key]) ?>;
<?php endif; endforeach; ?>
        }
    </style>
<?php endif; ?>
</head>
<body>
<div class="awfl-wrapper">
    <header class="awfl-header">
        <div class="awfl-header-inner">
            <a class="awfl-logo-link" href="<?= htmlspecialchars(awfl_page_url_raw('Main Page')) ?>">
                <img class="awfl-logo" src="<?= htmlspecialchars($logoUrl) ?>" alt="<?= htmlspecialchars($Sitename) ?> logo">
                <span class="awfl-sitename"><?= htmlspecialchars($Sitename) ?></span>
            </a>
            <form class="awfl-searchform" action="<?= htmlspecialchars(awfl_asset_url('index.php')) ?>" method="get">
                <input type="text" name="title" placeholder="Search <?= htmlspecialchars($Sitename) ?>" value="<?= htmlspecialchars($pagename !== $Sitename ? $pagename : '') ?>">
                <button type="submit">Search</button>
            </form>
            <nav class="awfl-usernav">
<?php if ($currentUser): ?>
                <span class="awfl-username">Hi, <?= htmlspecialchars($currentUser['name']) ?></span>
                <a href="<?= htmlspecialchars(awfl_asset_url('allusers/index.php')) ?>">All users</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('allimages/index.php')) ?>">All images</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('allpages/index.php')) ?>">All pages</a>
<?php if ($currentUser['is_admin']): ?>
                <a href="<?= htmlspecialchars(awfl_asset_url('dashboard/index.php')) ?>">Dashboard</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('dashboard/history.php')) ?>">History</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('set.php')) ?>">Set</a>
<?php endif; ?>
                <a href="<?= htmlspecialchars(awfl_asset_url('index.php?action=logout')) ?>">Log out</a>
<?php else: ?>
                <a href="<?= htmlspecialchars(awfl_page_url_raw('Special:Login')) ?>">Log in</a>
                <a href="<?= htmlspecialchars(awfl_page_url_raw('Special:Register')) ?>">Register</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('allusers/index.php')) ?>">All users</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('allimages/index.php')) ?>">All images</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('allpages/index.php')) ?>">All pages</a>
                <a href="<?= htmlspecialchars(awfl_asset_url('set.php')) ?>">Set</a>
<?php endif; ?>

            </nav>
        </div>
    </header>
    <div class="awfl-body">



















