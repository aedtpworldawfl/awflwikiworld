<?php
require_once __DIR__ . '/../includes/functions.php';

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    awfl_require_admin();
    $targetUsername = $_POST['username'] ?? '';
    $act = $_POST['user_action'] ?? '';
    $users = awfl_load_users();

    if ($act === 'delete') {
        $before = count($users);
        $users = array_values(array_filter($users, fn($u) => strcasecmp($u['username'], $targetUsername) !== 0));
        if (count($users) < $before) {
            awfl_save_users($users);
            $notice = "User \"$targetUsername\" was removed. Their contributions remain on the wiki.";
        } else {
            $error = 'User not found.';
        }
    } elseif ($act === 'rename') {
        $newUsername = trim($_POST['new_username'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_\-\.]{3,32}$/', $newUsername)) {
            $error = 'New username must be 3-32 characters (letters, numbers, - _ .).';
        } elseif (awfl_username_taken($newUsername)) {
            $error = 'That username is already taken.';
        } else {
            foreach ($users as &$u) {
                if (strcasecmp($u['username'], $targetUsername) === 0) $u['username'] = $newUsername;
            }
            unset($u);
            awfl_save_users($users);
            $notice = "Renamed \"$targetUsername\" to \"$newUsername\".";
        }
    } elseif ($act === 'setpassword') {
        $newPass = $_POST['new_password'] ?? '';
        if (strlen($newPass) < 6) {
            $error = 'Password must be at least 6 characters.';
        } else {
            foreach ($users as &$u) {
                if (strcasecmp($u['username'], $targetUsername) === 0) $u['password'] = password_hash($newPass, PASSWORD_DEFAULT);
            }
            unset($u);
            awfl_save_users($users);
            $notice = "Password updated for \"$targetUsername\".";
        }
    }
}

$users = awfl_load_users();
$pagename = 'All users';
$headerMode = 'interface';
require __DIR__ . '/../includes/header.php';
?>
<main class="awfl-main">
    <h1>All users</h1>
    <?php if ($notice): ?><p class="awfl-success"><?= htmlspecialchars($notice) ?></p><?php endif; ?>
    <?php if ($error): ?><p class="awfl-error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

    <table class="awfl-datatable">
        <thead><tr>
            <th>Username</th><th>Display name</th><th>Joined</th>
            <?php if (awfl_is_admin()): ?><th>Actions</th><?php endif; ?>
        </tr></thead>
        <tbody>
        <?php foreach ($users as $u): ?>
            <tr>
                <td><?= htmlspecialchars($u['username']) ?></td>
                <td><?= htmlspecialchars($u['name']) ?></td>
                <td><?= htmlspecialchars(substr($u['created_at'], 0, 10)) ?></td>
                <?php if (awfl_is_admin()): ?>
                <td>
                    <details>
                        <summary>Manage</summary>
                        <form method="post" style="margin-top:8px;">
                            <input type="hidden" name="username" value="<?= htmlspecialchars($u['username']) ?>">
                            <input type="hidden" name="user_action" value="rename">
                            <input type="text" name="new_username" placeholder="New username" required style="width:140px;">
                            <button type="submit">Rename</button>
                        </form>
                        <form method="post" style="margin-top:6px;">
                            <input type="hidden" name="username" value="<?= htmlspecialchars($u['username']) ?>">
                            <input type="hidden" name="user_action" value="setpassword">
                            <input type="password" name="new_password" placeholder="New password" required style="width:140px;">
                            <button type="submit">Set password</button>
                        </form>
                        <form method="post" style="margin-top:6px;" onsubmit="return confirm('Remove this user? Their contributions will remain.');">
                            <input type="hidden" name="username" value="<?= htmlspecialchars($u['username']) ?>">
                            <input type="hidden" name="user_action" value="delete">
                            <button type="submit" class="awfl-danger">Remove user</button>
                        </form>
                    </details>
                </td>
                <?php endif; ?>
            </tr>
        <?php endforeach; ?>
        <?php if (!$users): ?>
            <tr><td colspan="<?= awfl_is_admin() ? 4 : 3 ?>"><em>No registered users yet.</em></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>



















